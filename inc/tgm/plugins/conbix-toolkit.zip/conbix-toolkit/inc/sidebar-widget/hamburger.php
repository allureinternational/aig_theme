<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

CSF::createWidget('csf_hamburger_widget', array(
    'title'       => esc_html__('Hamburger Info - Conbix', 'conbix-toolkit'),
    'classname'   => 'csf-hamburge-widget',
    'description' =>  esc_html__('This Widget for Hamburger Menu - Conbix', 'conbix-toolkit'),
    'fields'      => array(

        array(
            'id'            => 'hamburger_logo',
            'type'          => 'media',
            'title'         => esc_html__('Hamburger Logo', 'conbix-toolkit'),
            'library'       => 'image',
            'url'           => false,
            'button_title'  => esc_html__('Upload', 'conbix-toolkit'),
            'default'       => array(
                'url'       => get_theme_file_uri('assets/img/logo-2.png'),
                'thumbnail' => get_theme_file_uri('assets/img/logo-2.png'),
            ),
        ),

        array(
            'id'      => 'hamburger_content',
            'type'    => 'textarea',
            'title'   => esc_html__('Content', 'conbix-toolkit'),
            'default' => esc_html__('Lorem Ipsome is Dummy Content', 'conbix-toolkit'),
        ),
        array(
            'id'      => 'hamburger_title',
            'type'    => 'text',
            'title'   => esc_html__('Contact Title', 'conbix-toolkit'),
            'default' => esc_html__('Get In Touch', 'conbix-toolkit'),
        ),

        array(
            'id'        => 'contact_info_group',
            'type'      => 'group',
            'title'     => esc_html__('Contact Info Lists', 'conbix-toolkit'),
            'fields'    => array(

                array(
                    'id'    => 'contact-title',
                    'type'  => 'text',
                    'title' => esc_html__('Title', 'conbix-toolkit'),
                ),
                array(
                    'id'      => 'contact-icon',
                    'type'    => 'icon',
                    'title'   => esc_html__('Icon', 'conbix-toolkit'),
                    'default' => 'fa fa-heart'
                ),
                array(
                    'id'    => 'contact-text',
                    'type'  => 'textarea',
                    'title' => esc_html__('Content', 'conbix-toolkit'),
                ),
                array(
                    'id'    => 'contact-url',
                    'type'  => 'text',
                    'title' => esc_html__('URL', 'conbix-toolkit'),
                ),
            ),
            'default'   => array(
                array(
                    'contact-title' => 'Office Address',
                    'contact-icon'  => 'fal fa-map-marker-alt',
                    'contact-text'  => esc_html__('8502 Preston Rd. Inglewood, Maine 98380', 'conbix-toolkit'),
                    'contact-url'   => esc_attr__('http://google.com/maps', 'conbix-toolkit'),
                ),
            ),
        ),

        array(
            'id'        => 'socials-group',
            'type'      => 'group',
            'title'     => esc_html__('Social Media Lists', 'conbix-toolkit'),
            'fields'    => array(
                array(
                    'id'      => 'social-icon',
                    'type'    => 'icon',
                    'title'   => esc_html__('Icon', 'conbix-toolkit'),
                    'default' => 'fa fa-facebook'
                ),
                array(
                    'id'     => 'social-url',
                    'type'   => 'text',
                    'title'  => esc_html__('URL', 'conbix-toolkit'),
                ),
            ),
            'default'   => array(
                array(
                    'social-icon'  => 'fab fa-facebook-f',
                    'social-url'   => 'facebook.com',
                ),
                array(
                    'social-icon'  => 'fab fa-twitter',
                    'social-url'   => 'twitter.com',
                ),
            ),
        ),

    )
));

if (!function_exists('csf_hamburger_widget')) {
    function csf_hamburger_widget($args, $instance)
    {

        echo $args['before_widget'];

        $hamburger_logo = $instance['hamburger_logo'];
        $hamburger_content = $instance['hamburger_content'];
        $hamburger_title = $instance['hamburger_title'];
        $socials = $instance['socials-group'];
        $contactinfos = $instance['contact_info_group'];
?>

        <!-- sidebar Menu Start -->
        <?php if (!empty($hamburger_logo['url'])) : ?>
            <div class="header__area-menubar-right-sidebar-popup-logo">
                <a href="<?php echo get_site_url(); ?>"> <img src="<?php echo esc_url($hamburger_logo['url']); ?>" alt="logo"> </a>
            </div>
        <?php endif; ?>
        <?php if (!empty($hamburger_content)) : ?>
            <p><?php echo esc_html($hamburger_content); ?></p>
        <?php endif; ?>

        <div class="header__area-menubar-right-box-sidebar-popup-contact">
            <?php if (!empty($hamburger_title)) : ?>
                <h4 class="mb-30"><?php echo esc_html($hamburger_title); ?></h4>
            <?php endif; ?>

            <?php if (is_array($contactinfos) || is_object($contactinfos)) : ?>
                <?php foreach ($contactinfos as $contact_in) { ?>
                    <div class="header__area-menubar-right-box-sidebar-popup-contact-item">
                        <div class="header__area-menubar-right-box-sidebar-popup-contact-item-icon">
                            <i class="<?php echo esc_attr($contact_in['contact-icon']); ?>"></i>
                        </div>
                        <div class="header__area-menubar-right-box-sidebar-popup-contact-item-content">
                            <span><?php echo esc_html($contact_in['contact-title']); ?></span>
                            <h6><a href="<?php echo esc_url($contact_in['contact-url']); ?>"><?php echo esc_html($contact_in['contact-text']); ?></a></h6>
                        </div>
                    </div>
                <?php } ?>
            <?php endif; ?>
        </div>

        <?php if (is_array($socials) || is_object($socials)) : ?>
            <div class="header__area-menubar-right-box-sidebar-popup-social">
                <ul>
                    <?php foreach ($socials as $social) { ?>
                        <li><a href="<?php echo esc_url($social['social-url']); ?>"><i class="<?php echo esc_attr($social['social-icon']); ?>"></i></a></li>
                    <?php } ?>
                </ul>
            </div>
        <?php endif; ?>
        <!-- sidebar Menu Start -->

<?php
        echo $args['after_widget'];
    }
}
