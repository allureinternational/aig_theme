<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

CSF::createWidget('csf_footer_three_widget', array(
    'title'       => esc_html__('Footer Three - Conbix', 'conbix-toolkit'),
    'classname'   => 'csf-footer-three-widget',
    'description' =>  esc_html__('This Widget for Footer Style 03 - Conbix', 'conbix-toolkit'),
    'fields'      => array(

        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget One', 'conbix-toolkit'),
        ),

        array(
            'id'           => 'widget_one_logo',
            'type'         => 'media',
            'title'        => esc_html__('Light Logo', 'conbix-toolkit'),
            'library'      => 'image',
            'url'          => false,
            'button_title' => esc_html__('Upload', 'conbix-toolkit'),
            'default'   => array(
                'url' => get_theme_file_uri('assets/img/logo-6.png'),
                'thumbnail' => get_theme_file_uri('assets/img/logo-6.png'),
            ),
        ),

        array(
            'id'           => 'widget_two_logo',
            'type'         => 'media',
            'title'        => esc_html__('Dark Logo', 'conbix-toolkit'),
            'library'      => 'image',
            'url'          => false,
            'button_title' => esc_html__('Upload', 'conbix-toolkit'),
            'default'   => array(
                'url' => get_theme_file_uri('assets/img/logo-7.png'),
                'thumbnail' => get_theme_file_uri('assets/img/logo-7.png'),
            ),
        ),

        array(
            'id'      => 'comapny_content',
            'type'    => 'textarea',
            'title'   => esc_html__('Content', 'conbix-toolkit'),
            'default' => esc_html__('Lorem Ipsum is Dummy Content', 'conbix-toolkit'),
        ),

        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget Two', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_two_title',
            'type'    => 'text',
            'title'   => esc_html__('Widget Two Title', 'conbix-toolkit'),
            'default' => esc_html__('Head Office', 'conbix-toolkit'),
        ),

        array(
            'id'        => 'widget_two_office',
            'type'      => 'group',
            'title'     => esc_html__('Office Info', 'conbix-toolkit'),
            'fields'    => array(

                array(
                    'id'     => 'office-title',
                    'type'   => 'text',
                    'title'  => esc_html__('Title', 'conbix-toolkit'),
                ),
                array(
                    'id'      => 'office-icon',
                    'type'    => 'icon',
                    'title'   => esc_html__('Icon', 'conbix-toolkit'),
                    'default' => 'fa fa-heart'
                ),
                array(
                    'id'     => 'office-text',
                    'type'   => 'textarea',
                    'title'  => esc_html__('Content', 'conbix-toolkit'),
                ),
                array(
                    'id'     => 'office-url',
                    'type'   => 'text',
                    'title'  => esc_html__('URL', 'conbix-toolkit'),
                ),
            ),
            'default'   => array(
                array(
                    'office-icon'  => 'fal fa-map-marker-alt',
                    'office-text'  => esc_html__('8502 Preston Rd. Inglewood, Maine 98380', 'conbix-toolkit'),
                    'office-url'   => esc_attr__('http://google.com/maps', 'conbix-toolkit'),
                    'office-title' =>  esc_html__('Branch Office', 'conbix-toolkit'),
                ),
            ),
        ),

        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget Three', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_three_title',
            'type'    => 'text',
            'title'   => esc_html__('Widget Three Title', 'conbix-toolkit'),
            'default' => esc_html__('Company', 'conbix-toolkit'),
        ),

        // Select with categories
        array(
            'id'          => 'widget_three_menu',
            'type'        => 'select',
            'title'       =>  esc_html__('Select Menu', 'conbix-toolkit'),
            'placeholder' =>  esc_attr__('Select a Menu', 'conbix-toolkit'),
            'options'     => 'menus',
        ),

        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget Four', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_four_title',
            'type'    => 'text',
            'title'   => esc_html__('Widget Four Title', 'conbix-toolkit'),
            'default' => esc_html__('Working Time', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'four_content',
            'type'    => 'group',
            'title'   => esc_html__('Content', 'conbix-toolkit'),
            'fields'    => array(
                array(
                    'id'    => 'four-text',
                    'type'  => 'text',
                    'title' => esc_html__('Content', 'conbix-toolkit'),
                ),
            ),
            'default'   => array(
                array(
                    'four-text'   => esc_html__('Mon - fri : 9:00 AM - 5:00 PM', 'conbix-toolkit'),
                ),
                array(
                    'four-text'   => esc_html__('Sat : 10:00 AM - 6:00 PM', 'conbix-toolkit'),
                ),
                array(
                    'four-text'   => esc_html__('Sunday Close', 'conbix-toolkit'),
                ),
            ),
        ),

        array(
            'id'        => 'socials_group',
            'type'      => 'group',
            'title'     => esc_html__('Social Media Lists', 'conbix-toolkit'),
            'fields'    => array(
                array(
                    'id'      => 'social-icon',
                    'type'    => 'icon',
                    'title'   => esc_html__('Icon', 'conbix-toolkit'),
                    'default' => 'fa fa-facebook'
                ),
                array(
                    'id'    => 'social-url',
                    'type'  => 'text',
                    'title' => esc_html__('URL', 'conbix-toolkit'),
                ),
            ),
            'default'   => array(
                array(
                    'social-icon'  => 'fab fa-facebook-f',
                    'social-url'   => 'facebook.com',
                ),
                array(
                    'social-icon'  => 'fab fa-twitter',
                    'social-url'   => 'twitter.com',
                ),
            ),
        ),

    )
));

if (!function_exists('csf_footer_three_widget')) {
    function csf_footer_three_widget($args, $instance)
    {

        echo $args['before_widget'];

        $light_logo = $instance['widget_one_logo'];
        $dark_logo = $instance['widget_two_logo'];
        $comapny_content = $instance['comapny_content'];
        $widget_two_title = $instance['widget_two_title'];
        $widget_two_office = $instance['widget_two_office'];
        $widget_three_title = $instance['widget_three_title'];
        $selected_menu = $instance['widget_three_menu'];
        $widget_four_title = $instance['widget_four_title'];
        $four_content = $instance['four_content'];
        $socials = $instance['socials_group'];
?>


        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-5 col-md-7 md-mb-30">
                    <div class="footer__three-widget">
                        <div class="footer__three-widget-about">
                            <a href="<?php echo get_site_url(); ?>">
                                <img class="dark-n" src="<?php echo esc_url($light_logo['url']); ?>" alt="logo">
                                <img class="light-n" src="<?php echo esc_url($dark_logo['url']); ?>" alt="logo">
                            </a>
                            <p><?php echo esc_html($comapny_content); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-5 col-sm-7 xl-mb-30">
                    <div class="footer__three-widget">
                        <h4><?php echo esc_html($widget_two_title); ?></h4>
                        <div class="footer__three-widget-location">
                            <?php if (is_array($widget_two_office) || is_object($widget_two_office)) : ?>
                                <?php foreach ($widget_two_office as $widget_two_off) { ?>
                                    <?php if (!empty($widget_two_off['office-title'])) : ?><h6><?php echo esc_html($widget_two_off['office-title']); ?></h6><?php endif; ?>
                                    <div class="footer__three-widget-location-item">
                                        <div class="footer__three-widget-location-item-icon">
                                            <i class="<?php echo esc_attr($widget_two_off['office-icon']); ?>"></i>
                                        </div>
                                        <div class="footer__three-widget-location-item-info">
                                            <a href="<?php echo esc_url($widget_two_off['office-url']); ?>"><?php echo esc_html($widget_two_off['office-text']); ?></a>
                                        </div>
                                    </div>
                                <?php } ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-5 sm-mb-30">
                    <div class="footer__three-widget">
                        <h4><?php echo esc_html($widget_three_title); ?></h4>
                        <div class="footer__three-widget-solution">
                            <?php
                            wp_nav_menu(array(
                                'menu' => $selected_menu,
                            ));
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-5">
                    <div class="footer__three-widget border-one tow">
                        <h4><?php echo esc_html($widget_four_title); ?></h4>
                        <div class="footer__three-widget-hour">
                            <?php if (is_array($four_content) || is_object($four_content)) : ?>
                                <?php foreach ($four_content as $four_cont) { ?>
                                    <p><?php echo esc_html($four_cont['four-text']); ?></p>
                                <?php } ?>
                            <?php endif; ?>
                            <?php if (is_array($socials) || is_object($socials)) : ?>
                                <div class="footer__three-widget-hour-social">
                                    <ul>
                                        <?php foreach ($socials as $social) { ?>
                                            <li><a href="<?php echo esc_url($social['social-url']); ?>"><i class="<?php echo esc_attr($social['social-icon']); ?>"></i></a></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php
        echo $args['after_widget'];
    }
}
