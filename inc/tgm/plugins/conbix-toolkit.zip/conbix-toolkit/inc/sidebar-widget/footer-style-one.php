<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

CSF::createWidget('csf_footer_one_widget', array(
    'title'       => esc_html__('Footer One - Conbix', 'conbix-toolkit'),
    'classname'   => 'csf-footer-one-widget',
    'description' =>  esc_html__('This Widget for Footer Style 01 - Conbix', 'conbix-toolkit'),
    'fields'      => array(

        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget One', 'conbix-toolkit'),
        ),

        array(
            'id'           => 'widget_one_logo',
            'type'         => 'media',
            'title'        => esc_html__('Hamburger Logo', 'conbix-toolkit'),
            'library'      => 'image',
            'url'          => false,
            'button_title' => esc_html__('Upload', 'conbix-toolkit'),
            'default'   => array(
                'url' => get_theme_file_uri('assets/img/logo-2.png'),
                'thumbnail' => get_theme_file_uri('assets/img/logo-2.png'),
            ),
        ),

        array(
            'id'      => 'comapny_content',
            'type'    => 'textarea',
            'title'   => esc_html__('Content', 'conbix-toolkit'),
            'default' => esc_html__('Lorem Ipsum is Dummy Content', 'conbix-toolkit'),
        ),

        array(
            'id'        => 'socials_group',
            'type'      => 'group',
            'title'     => esc_html__('Social Media Lists', 'conbix-toolkit'),
            'fields'    => array(
                array(
                    'id'      => 'social-icon',
                    'type'    => 'icon',
                    'title'   => esc_html__('Icon', 'conbix-toolkit'),
                    'default' => 'fa fa-facebook'
                ),
                array(
                    'id'    => 'social-url',
                    'type'  => 'text',
                    'title' => esc_html__('URL', 'conbix-toolkit'),
                ),
            ),
            'default'   => array(
                array(
                    'social-icon'  => 'fab fa-facebook-f',
                    'social-url'   => 'facebook.com',
                ),
                array(
                    'social-icon'  => 'fab fa-twitter',
                    'social-url'   => 'twitter.com',
                ),
            ),
        ),

        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget Two', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_two_title',
            'type'    => 'text',
            'title'   => esc_html__('Widget Two Title', 'conbix-toolkit'),
            'default' => esc_html__('Our Solution', 'conbix-toolkit'),
        ),

        // Select with categories
        array(
            'id'          => 'widget_two_menu',
            'type'        => 'select',
            'title'       =>  esc_html__('Select Menu', 'conbix-toolkit'),
            'placeholder' =>  esc_attr__('Select a Menu', 'conbix-toolkit'),
            'options'     => 'menus',
        ),
        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget Three', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_three_title',
            'type'    => 'text',
            'title'   => esc_html__('Widget Three Title', 'conbix-toolkit'),
            'default' => esc_html__('Head Office', 'conbix-toolkit'),
        ),

        array(
            'id'        => 'widget_three_office',
            'type'      => 'group',
            'title'     => esc_html__('Office Info', 'conbix-toolkit'),
            'fields'    => array(

                array(
                    'id'     => 'office-title',
                    'type'   => 'text',
                    'title'  => esc_html__('Title', 'conbix-toolkit'),
                ),
                array(
                    'id'      => 'office-icon',
                    'type'    => 'icon',
                    'title'   => esc_html__('Icon', 'conbix-toolkit'),
                    'default' => 'fa fa-heart'
                ),
                array(
                    'id'     => 'office-text',
                    'type'   => 'textarea',
                    'title'  => esc_html__('Content', 'conbix-toolkit'),
                ),
                array(
                    'id'     => 'office-url',
                    'type'   => 'text',
                    'title'  => esc_html__('URL', 'conbix-toolkit'),
                ),
            ),
            'default'   => array(
                array(
                    'office-icon'  => 'fal fa-map-marker-alt',
                    'office-text'  => esc_html__('8502 Preston Rd. Inglewood, Maine 98380', 'conbix-toolkit'),
                    'office-url'   => esc_attr__('http://google.com/maps', 'conbix-toolkit'),
                    'office-title' => 'Branch Office',
                ),
            ),
        ),

        // A Subheading
        array(
            'type'    => 'subheading',
            'content' => esc_html__('Widget Four', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_four_title',
            'type'    => 'text',
            'title'   => esc_html__('Widget Four Title', 'conbix-toolkit'),
            'default' => esc_html__('Subscribe', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_four_content',
            'type'    => 'textarea',
            'title'   => esc_html__('Content', 'conbix-toolkit'),
            'default' => esc_html__('Join over 68,000 people getting our emails', 'conbix-toolkit'),
        ),

        array(
            'id'      => 'widget_four_form',
            'type'    => 'number',
            'title'   => esc_html__('Subscribe Form id', 'conbix-toolkit'),
            'desc'    => esc_html__('Worked with Contact Form 7 Unique ID Only. Like a Number: 12', 'conbix-toolkit'),
            'default' => esc_html__('00', 'conbix-toolkit'),
        ),
    )
));

if (!function_exists('csf_footer_one_widget')) {
    function csf_footer_one_widget($args, $instance)
    {

        echo $args['before_widget'];

        $widget_logo = $instance['widget_one_logo'];
        $selected_menu = $instance['widget_two_menu'];
        $comapny_content = $instance['comapny_content'];
        $socials = $instance['socials_group'];
        $widget_two_title = $instance['widget_two_title'];
        $widget_three_title = $instance['widget_three_title'];
        $widget_three_office = $instance['widget_three_office'];
        $widget_four_title = $instance['widget_four_title'];
        $widget_four_content = $instance['widget_four_content'];
        $widget_four_form = $instance['widget_four_form'];

        $htmls = array(
            'strong' => array(),
            'small'  => array(),
            'span'   => array(),
        );
?>

        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-md-6 col-sm-7 xl-mb-30">
                    <div class="footer__one-widget">
                        <div class="footer__one-widget-about">
                            <?php if (!empty($widget_logo['url'])) : ?>
                                <a href="<?php echo get_site_url(); ?>"> <img src="<?php echo esc_url($widget_logo['url']); ?>" alt="logo"> </a>
                            <?php endif ?>
                            <p><?php echo esc_html($comapny_content); ?></p>
                            <?php if (is_array($socials) || is_object($socials)) : ?>
                                <div class="footer__one-widget-about-social">
                                    <ul>
                                        <?php foreach ($socials as $social) { ?>
                                            <li><a href="<?php echo esc_url($social['social-url']); ?>"><i class="<?php echo esc_attr($social['social-icon']); ?>"></i></a></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 col-sm-5 sm-mb-30">
                    <div class="footer__one-widget border-one">
                        <h4><?php echo esc_html($widget_two_title); ?></h4>
                        <div class="footer__one-widget-solution">
                            <?php
                            wp_nav_menu(array(
                                'menu' => $selected_menu,
                            ));
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 col-sm-6 sm-mb-30">
                    <div class="footer__one-widget border-one">
                        <h4><?php echo esc_html($widget_three_title); ?></h4>
                        <div class="footer__one-widget-location">
                            <?php if (is_array($widget_three_office) || is_object($widget_three_office)) : ?>
                                <?php foreach ($widget_three_office as $widget_three_off) { ?>
                                    <?php if (!empty($widget_three_off['office-title'])) : ?><h6><?php echo esc_html($widget_three_off['office-title']); ?></h6><?php endif; ?>
                                    <div class="footer__one-widget-location-item">
                                        <div class="footer__one-widget-location-item-icon">
                                            <i class="<?php echo esc_attr($widget_three_off['office-icon']); ?>"></i>
                                        </div>
                                        <div class="footer__one-widget-location-item-info">
                                            <a href="<?php echo esc_url($widget_three_off['office-url']); ?>"><?php echo esc_html($widget_three_off['office-text']); ?></a>
                                        </div>
                                    </div>
                                <?php } ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 col-sm-6">
                    <div class="footer__one-widget border-one tow">
                        <h4><?php echo esc_html($widget_four_title); ?></h4>
                        <div class="footer__one-widget-subscribe">
                            <p><?php echo wp_kses($widget_four_content, $htmls); ?></p>
                            <?php if (!empty($widget_four_form)) : ?>
                                <div class="subscribe-form-home-one">
                                    <?php echo do_shortcode('[contact-form-7 id="' . $widget_four_form . '" ]'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php
        echo $args['after_widget'];
    }
}
