<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Blog_Grid extends Widget_Base
{


	public function get_name()
	{
		return 'blog_grid';
	}


	public function get_title()
	{
		return esc_html__('Blog Grid', 'conbix-toolkit');
	}


	public function get_icon()
	{
		return 'eicon-gallery-grid';
	}


	public function get_categories()
	{
		return ['conbix-toolkit'];
	}

	public function get_keywords()
	{
		return ['Conbix', 'Toolkit', 'Blog', 'Grid'];
	}

	protected function register_controls()
	{

		$this->start_controls_section(
			'section_general',
			[
				'label' => esc_html__('Style & Column', 'conbix-toolkit'),
			]
		);

		$this->add_control(
			'select_design',
			[
				'label'   => esc_html__('Select a Style', 'conbix-toolkit'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'design-1' => esc_html__('Blog Style 01', 'conbix-toolkit'),
					'design-2' => esc_html__('Blog Style 02', 'conbix-toolkit'),
					'design-3' => esc_html__('Blog Style 03', 'conbix-toolkit'),
				],
				'default'      => 'design-1',
				'label_block'  => true,
			]
		);

		$this->add_control(
			'columns_desktop',
			[
				'label'   => esc_html__('Columns On Desktop', 'conbix-toolkit'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'col-xl-6' => esc_html__('Column 2', 'conbix-toolkit'),
					'col-xl-4' => esc_html__('Column 3', 'conbix-toolkit'),
					'col-xl-3' => esc_html__('Column 4', 'conbix-toolkit'),
				],
				'default'      => 'col-xl-4',
				'label_block'  => true,
			]
		);

		$this->add_control(
			'columns_tab',
			[
				'label'   => esc_html__('Columns On Tablet', 'conbix-toolkit'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'col-lg-12' => esc_html__('1 Column', 'conbix-toolkit'),
					'col-lg-6'  => esc_html__('2 Column', 'conbix-toolkit'),
				],
				'default'      => 'col-lg-6',
				'label_block'  => true,
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'blog_head',
			[
				'label' => esc_html__('Blog Heading', 'conbix-toolkit'),
			]
		);

		$this->add_control(
			'show_head',
			[
				'label' => esc_html__('Show Heading', 'conbix-toolkit'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Yes', 'conbix-toolkit'),
				'label_off' => esc_html__('No', 'conbix-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__('Sub Title', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('From the blog', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'show_head' => ['yes'],
				],
			]
		);
		$this->add_control(
			'title_one',
			[
				'label' => esc_html__('Title', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('News & Articles', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'show_head' => ['yes'],
				],
			]
		);
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__('Button Text', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('See more blog', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'show_head'     => ['yes'],
					'select_design' => ['design-1', 'design-2'],
				],
			]
		);
		$this->add_control(
			'btn_url',
			[
				'label' => esc_html__('Button URL', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_attr__('http://google.com', 'conbix-toolkit'),
				'condition' => [
					'show_head' => ['yes'],
					'select_design' => ['design-1', 'design-2'],
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'blog_query',
			[
				'label' => esc_html__('Blog Query', 'conbix-toolkit'),
			]
		);


		$this->add_control(
			'post_count',
			[
				'label' => esc_html__('Number Of Posts', 'conbix-toolkit'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['count'],
				'range' => [
					'count' => [
						'min' => 2,
						'max' => 15,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'count',
					'size' => 3,
				],
			]
		);

		$this->add_control(
			'word_limit',
			[
				'label' => esc_html__('Content Word Limit', 'conbix-toolkit'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['count'],
				'range' => [
					'count' => [
						'min' => 5,
						'max' => 50,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'count',
					'size' => 10,
				],
			]
		);

		$this->add_control(
			'category',
			[
				'label'       => esc_html__('Categories', 'conbix-toolkit'),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => conbix_post_categories(),
			]
		);

		$this->add_control(
			'blog_btn_text',
			[
				'label' => esc_html__('Blog Button', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Read More', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-2', 'design-3'],
				],
			]
		);


		$this->end_controls_section();
	}


	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$blog_column = $settings['columns_desktop'] . ' ' . $settings['columns_tab'];

		if (!empty($settings['category'])) {
			$post_query = new \WP_Query(array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'posts_per_page'      => $settings['post_count']['size'],
				'ignore_sticky_posts' => 1,
				'tax_query'           => array(
					array(
						'taxonomy' => 'category',
						'terms'    => $settings['category'],
						'field'    => 'slug',
					)
				)
			));
		} else {

			$post_query = new \WP_Query(
				array(
					'post_type'           => 'post',
					'post_status'         => 'publish',
					'posts_per_page'      => $settings['post_count']['size'],
					'ignore_sticky_posts' => 1,
				)
			);
		}

?>
		<?php if ('design-1' === $settings['select_design']) : ?>
			<div class="blog__one dark__image">
				<div class="container">
					<?php if ('yes' === $settings['show_head']) : ?>
						<div class="row align-items-end mb-45">
							<div class="col-xl-7 col-lg-8 lg-mb-30">
								<div class="blog__one-title lg-t-center">
									<span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
									<h2><?php echo esc_html($settings['title_one']); ?></h2>
								</div>
							</div>
							<div class="col-xl-5 col-lg-4 t-right lg-t-center">
								<a class="btn-two" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
							</div>
						</div>
					<?php endif; ?>
					<div class="row">
						<?php while ($post_query->have_posts()) : $post_query->the_post(); ?>
							<div class="<?php echo esc_attr($blog_column); ?>">
								<div class="blog__one-item mt-25">
									<div class="blog__one-item-image">
										<a href="<?php the_permalink(); ?>">
											<img class="img__full" src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
										</a>
										<div class="blog__one-item-image-date">
											<span class="text-three"><?php echo get_the_date('d') ?></span>
											<span class="text-five"><?php echo get_the_date('M') ?></span>
										</div>
									</div>
									<div class="blog__one-item-content">
										<div class="blog__one-item-content-meta">
											<ul>
												<li><a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"><i class="far fa-user"></i><?php the_author(); ?></a></li>
												<li><a href="<?php the_permalink(); ?>"><i class="far fa-comment-dots"></i>
														<?php conbix_comments_count(); ?></a></li>
											</ul>
										</div>
										<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										<p><?php echo wp_trim_words(get_the_content(), ($settings['word_limit']['size']), '...'); ?></p>
									</div>
								</div>
							</div>
						<?php
						endwhile;
						wp_reset_query();
						?>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php if ('design-2' === $settings['select_design']) : ?>
			<div class="blog__two">
				<div class="container">
					<?php if ('yes' === $settings['show_head']) : ?>
						<div class="row align-items-end mb-45">
							<div class="col-xl-7 col-lg-7 lg-mb-30">
								<div class="blog__two-title lg-t-center">
									<span class="subtitle-two"><?php echo esc_html($settings['sub_title']); ?></span>
									<h2><?php echo esc_html($settings['title_one']); ?></h2>
								</div>
							</div>
							<div class="col-xl-5 col-lg-5 t-right lg-t-center">
								<a class="btn-six" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
							</div>
						</div>
					<?php endif; ?>
					<div class="row">
						<?php while ($post_query->have_posts()) : $post_query->the_post(); ?>
							<div class="<?php echo esc_attr($blog_column); ?>">
								<div class="blog__two-item mt-25">
									<div class="blog__two-item-image">
										<a href="<?php the_permalink(); ?>">
											<img class="img__full" src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
										</a>
										<div class="blog__two-item-image-date">
											<span class="text-three"><?php echo get_the_date('d') ?></span>
											<span class="text-five"><?php echo get_the_date('M') ?></span>
										</div>
									</div>
									<div class="blog__two-item-content">
										<div class="blog__two-item-content-meta">
											<ul>
												<li><a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"><i class="far fa-user"></i><?php the_author(); ?></a></li>
												<li><a href="<?php the_permalink(); ?>"><i class="far fa-comment-dots"></i>
														<?php conbix_comments_count(); ?></a></li>
											</ul>
										</div>
										<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										<a class="btn-six" href="<?php the_permalink(); ?>"><?php echo esc_html($settings['blog_btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
									</div>
								</div>
							</div>
						<?php
						endwhile;
						wp_reset_query();
						?>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php if ('design-3' === $settings['select_design']) : ?>
			<div class="blog__three dark__image">
				<div class="container">
					<?php if ('yes' === $settings['show_head']) : ?>
						<div class="row align-items-end mb-45">
							<div class="col-xl-12">
								<div class="blog__three-title t-center">
									<span class="subtitle-three"><?php echo esc_html($settings['sub_title']); ?></span>
									<h2><?php echo esc_html($settings['title_one']); ?></h2>
								</div>
							</div>
						</div>
					<?php endif; ?>
					<div class="row">
						<?php
						$i = 0;
						while ($post_query->have_posts()) : $post_query->the_post();
							$i++;
						?>
							<div class="<?php echo esc_attr($blog_column); ?>">
								<div class="blog__three-item mt-25 <?php echo ($i == 1) ? 'blog__three-item-hover' : ''; ?>">
									<div class="blog__three-item-image">
										<a href="<?php the_permalink(); ?>">
											<img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
										</a>
									</div>
									<div class="blog__three-item-content">
										<div class="blog__three-item-content-meta">
											<ul>
												<li><a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"><i class="far fa-user"></i><?php the_author(); ?></a></li>
												<li><a href="<?php the_permalink(); ?>"><i class="far fa-comment-dots"></i>
														<?php conbix_comments_count(); ?></a></li>
											</ul>
										</div>
										<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										<div class="blog__three-item-content-btn">
											<a class="simple-btn-1" href="<?php the_permalink(); ?>"><?php echo esc_html($settings['blog_btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
										</div>
									</div>
								</div>
							</div>
						<?php
						endwhile;
						wp_reset_query();
						?>
					</div>
				</div>
			</div>
		<?php endif; ?>
<?php
	}
}

Plugin::instance()->widgets_manager->register(new Blog_Grid);
