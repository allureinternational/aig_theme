<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Our_FAQs extends Widget_Base
{
    public function get_name()
    {
        return 'our-faq';
    }

    public function get_title()
    {
        return esc_html__('Our FAQ', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'toggle', 'accordion', 'faq'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
            ]
        );

        $faqs_item = new Repeater();

        $faqs_item->add_control(
            'faq_title',
            [
                'label'   => esc_html__('FAQ Title', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $faqs_item->add_control(
            'faq_description',
            [
                'label'   => esc_html__('FAQ Content', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'faq_items',
            [
                'label' => esc_html__('FAQ Items', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $faqs_item->get_controls(),
                'default' => [
                    [
                        'faq_title'        => esc_html__('What is required of a consultant?', 'conbix-toolkit'),
                        'faq_description'  => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'conbix-toolkit'),
                    ],
                    [
                        'faq_title'        => esc_html__('Open a Business Bank Account?', 'conbix-toolkit'),
                        'faq_description'  => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'conbix-toolkit'),
                    ],
                    [
                        'faq_title'        => esc_html__('How do you prioritize your work?', 'conbix-toolkit'),
                        'faq_description'  => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ faq_title }}}',
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

?>
        <div class="faq-collapse">
            <?php foreach ($settings['faq_items'] as $keys => $item) : ?>
                <div class="faq-collapse-item">
                    <div class="faq-collapse-item-card">
                        <div class="faq-collapse-item-card-header">
                            <h6><span class="far fa-question-circle"></span><?php echo esc_html($item['faq_title']); ?></h6>
                            <i class="far fa-minus"></i>
                        </div>
                        <div class="faq-collapse-item-card-header-content <?php echo $keys === 0 ? 'active' : 'display-none'; ?>">
                            <p><?php echo esc_html($item['faq_description']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Our_FAQs);
