<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Icon_Info_box extends Widget_Base
{
    public function get_name()
    {
        return 'icon-info-conbix';
    }

    public function get_title()
    {
        return esc_html__('Icon Info', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-builder'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'contact', 'info', 'icon box'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'item_icon',
            [
                'label' => esc_html__('Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fa fa-phone',
                    'library' => 'regular',
                ],
            ]
        );

        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('123-456-7890', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('http://google.com', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'conbix-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'a_color',
            [
                'label' => esc_html__('Color', 'conbix-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .footer__one-widget-location-item-info a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'a_hover_color',
            [
                'label' => esc_html__('Hover Color', 'conbix-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .footer__one-widget-location-item-info a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .footer__one-widget-location-item-icon i' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->add_control(
            'border_color',
            [
                'label' => esc_html__('Border Color', 'conbix-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .footer__one-widget-location-item-icon i' => 'border-color: {{VALUE}}',
                ],
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>
        <div class="footer__one-widget-location-item">
            <div class="footer__one-widget-location-item-icon">
                <i class="<?php echo esc_attr($settings['item_icon']['value']); ?>"></i>
            </div>
            <div class="footer__one-widget-location-item-info">
                <a href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?></a>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Icon_Info_box);