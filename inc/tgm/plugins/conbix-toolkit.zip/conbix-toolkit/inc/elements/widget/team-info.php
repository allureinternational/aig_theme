<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Team_Info extends Widget_Base
{
    public function get_name()
    {
        return 'team-info';
    }

    public function get_title()
    {
        return esc_html__('Team Info', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Info', 'team', 'Icon Item'];
    }

    protected function register_controls()

    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );
        $team_info = new Repeater();

        $team_info->add_control(
            'item_icon',
            [
                'label' => esc_html__('Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fa fa-check',
                    'library' => 'regular',
                ],
            ]
        );
        $team_info->add_control(
            'sub_title',
            [
                'label'   => esc_html__('Sub Title', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $team_info->add_control(
            'title',
            [
                'label'   => esc_html__('Title', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $team_info->add_control(
            'title_url',
            [
                'label'   => esc_html__('URL', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'info_list',
            [
                'label' => esc_html__('Info Lists', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $team_info->get_controls(),
                'default' => [
                    [
                        'title'      => esc_html__('example@gmail.com', 'conbix-toolkit'),
                        'sub_title'  => esc_html__('Our Mail', 'conbix-toolkit'),
                        'title_url'  => esc_attr__('mailto:example@gmail.com', 'conbix-toolkit'),
                    ],

                    [
                        'title'      => esc_html__('+093929349232', 'conbix-toolkit'),
                        'sub_title'  => esc_html__('Our Phone', 'conbix-toolkit'),
                        'title_url'  => esc_attr__('tel:093929349232', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

?>
        <?php foreach ($settings['info_list'] as $key => $item) : ?>
            <div class="team__details-content-contact-item<?php echo ($key === 0) ? '' : ' mt-25'; ?>">
                <i class="<?php echo esc_attr($item['item_icon']['value']); ?>"></i>
                <div class="team__details-content-contact-item-info">
                    <span><?php echo esc_html($item['sub_title']); ?></span>
                    <h5><a href="<?php echo esc_url($item['title_url']); ?>"><?php echo esc_html($item['title']); ?></a></h5>
                </div>
            </div>
        <?php endforeach; ?>

<?php
    }
}

Plugin::instance()->widgets_manager->register(new Team_Info);
