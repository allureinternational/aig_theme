<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if (!defined('ABSPATH')) exit;

class Why_US extends Widget_Base
{


	public function get_name()
	{
		return 'why-us';
	}


	public function get_title()
	{
		return esc_html__('Why Us', 'conbix-toolkit');
	}


	public function get_icon()
	{
		return 'eicon-gallery-grid';
	}


	public function get_categories()
	{
		return ['conbix-toolkit'];
	}

	public function get_keywords()
	{
		return ['Conbix', 'Toolkit', 'About', 'Why Us'];
	}

	protected function register_controls()
	{

		$this->start_controls_section(
			'section_general',
			[
				'label' => esc_html__('Design Style', 'conbix-toolkit'),
			]
		);

		$this->add_control(
			'select_design',
			[
				'label'   => esc_html__('Select Style', 'conbix-toolkit'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'design-1' => esc_html__('Design 01', 'conbix-toolkit'),
					'design-2' => esc_html__('Design 02', 'conbix-toolkit'),
					'design-3' => esc_html__('Design 03', 'conbix-toolkit'),
					'design-4' => esc_html__('Design 04', 'conbix-toolkit'),
				],
				'default'      => 'design-1',
				'label_block'  => true,
			]
		);

		$this->add_control(
			'theme_shape',
			[
				'label'        => esc_html__( 'Element Shapes', 'conbix-toolkit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'conbix-toolkit' ),
				'label_off'    => esc_html__( 'Hide', 'conbix-toolkit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition' => [
					'select_design' => ['design-1','design-2','design-3'],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'why_image',
			[
				'label' => esc_html__('Section Image', 'conbix-toolkit'),
			]
		);

		$this->add_control(
			'image_one',
			[
				'label' => esc_html__('Image One', 'conbix-toolkit'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'image_two',
			[
				'label' => esc_html__('Image Two', 'conbix-toolkit'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'select_design' => ['design-1'],
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'one_content',
			[
				'label' => esc_html__('Section Content', 'conbix-toolkit'),
			]
		);

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__('Sub Title', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Who we are', 'conbix-toolkit'),
				'label_block' => true,
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('best company Especially in Business', 'conbix-toolkit'),
				'label_block' => true,
			]
		);
		$this->add_control(
			'description',
			[
				'label' => esc_html__('Content', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__('Aenean ac vulputate nibh, sed fringilla metus. Pellentesque porttitor felis eu nunc feugiat', 'conbix-toolkit'),
				'condition' => [
					'select_design!' => ['design-3'],
				],
			]
		);
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__('Button Text', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Read More', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design!' => ['design-3'],
				],
			]
		);
		$this->add_control(
			'btn_url',
			[
				'label' => esc_html__('Button URL', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_attr__('http://google.com', 'conbix-toolkit'),
				'condition' => [
					'select_design!' => ['design-3'],
				],
			]
		);


		$this->add_control(
			'heading_one',
			[
				'label' => esc_html__('Skills', 'conbix-toolkit'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'select_design' => ['design-1'],
				],
			]
		);

		$this->add_control(
			'skill_1',
			[
				'label' => esc_html__('Skill Title One', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Business Consulting', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-1'],
				],
			]
		);

		$this->add_control(
			'skill_lavel_1',
			[
				'label' => esc_html__('Skill Lavel One', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('80', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-1'],
				],
			]
		);

		$this->add_control(
			'skill_2',
			[
				'label' => esc_html__('Skill Title Two', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Business Consulting', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-1'],
				],
			]
		);

		$this->add_control(
			'skill_lavel_2',
			[
				'label' => esc_html__('Skill Lavel Two', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('90', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-1'],
				],
			]
		);

		$this->add_control(
			'counter',
			[
				'label' => esc_html__('Counter', 'conbix-toolkit'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'select_design' => ['design-3', 'design-4'],
				],
			]
		);

		$this->add_control(
			'counter_point',
			[
				'label' => esc_html__('Number 1', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('180', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-3', 'design-4'],
				],
			]
		);

		$this->add_control(
			'counter_title',
			[
				'label' => esc_html__('Counter Title 1', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Get International Award our company', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-3', 'design-4'],
				],
			]
		);

		$this->add_control(
			'counter_point2',
			[
				'label' => esc_html__('Number 2', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('180', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-4'],
				],
			]
		);

		$this->add_control(
			'counter_title2',
			[
				'label' => esc_html__('Counter Title 2', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Get International Award our company', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-4'],
				],
			]
		);


		$this->add_control(
			'features',
			[
				'label' => esc_html__('Features', 'conbix-toolkit'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'select_design' => ['design-2', 'design-3'],
				],
			]
		);

		$this->add_control(
			'icon_one',
			[
				'label' => esc_html__('Icon One', 'conbix-toolkit'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'select_design' => ['design-3'],
				],
			]
		);

		$this->add_control(
			'item_one',
			[
				'label' => esc_html__('Title One', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Teaching and training employees.', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-2', 'design-3'],
				],
			]
		);

		$this->add_control(
			'desc_1',
			[
				'label' => esc_html__('Content One', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__('Aenean ac vulputate nibh, sed fringilla metus', 'conbix-toolkit'),
				'condition' => [
					'select_design' => ['design-3'],
				],
			]
		);

		$this->add_control(
			'icon_two',
			[
				'label' => esc_html__('Icon Two', 'conbix-toolkit'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'select_design' => ['design-3'],
				],
			]
		);

		$this->add_control(
			'item_two',
			[
				'label' => esc_html__('Title Two', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Project management consulting.', 'conbix-toolkit'),
				'label_block' => true,
				'condition' => [
					'select_design' => ['design-2', 'design-3'],
				],
			]
		);
		$this->add_control(
			'desc_2',
			[
				'label' => esc_html__('Content Two', 'conbix-toolkit'),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__('Aenean ac vulputate nibh, sed fringilla metus', 'conbix-toolkit'),
				'condition' => [
					'select_design' => ['design-3'],
				],
			]
		);

		$this->end_controls_section();
	}


	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$image_one = $settings['image_one'];
		$image_two = $settings['image_two'];

?>
		<?php if ('design-1' === $settings['select_design']) : ?>
			<div class="experience__area dark__image section-padding">
		     	<?php if ('yes' === $settings['theme_shape']) : ?>
				<img class="experience__area-shape dark-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/experience.png')); ?>" alt="shape">
				<img class="experience__area-shape light-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/experience-dark.png')); ?>" alt="shape">
				<?php endif;?>
				<div class="container">
					<div class="row align-items-center">
						<div class="col-xl-6 col-lg-6 lg-mb-30">
							<div class="experience__area-image">
							    <?php if ('yes' === $settings['theme_shape']) : ?>
								<img class="experience__area-image-shape left-right-animate" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/dots.png')); ?>" alt="dots">
								<?php endif;?>
								<div class="experience__area-image-item">
									<?php
									if ($image_one['url']) {
										if (!empty($image_one['alt'])) {
											echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
										} else {
											echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
										}
									}
									?>
								</div>
								<div class="experience__area-image-item mt-65">
									<?php
									if ($image_two['url']) {
										if (!empty($image_two['alt'])) {
											echo '<img class="two" src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
										} else {
											echo '<img class="two" src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
										}
									}
									?>
								</div>
							</div>
						</div>
						<div class="col-xl-6 col-lg-6">
							<div class="experience__area-right">
								<div class="experience__area-right-title">
									<span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
									<h2><?php echo esc_html($settings['title']); ?></h2>
									<p><?php echo esc_html($settings['description']); ?></p>
								</div>
								<div class="experience__area-right-skill">
									<div class="experience__area-right-skill-item">
										<div class="experience__area-right-skill-item-content">
											<span class="text-two"><?php echo esc_html($settings['skill_1']); ?></span>
											<span class="experience__area-right-skill-item-count text-two"><span class="counter"><?php echo esc_attr($settings['skill_lavel_1']); ?></span><?php echo esc_html('%'); ?></span>
										</div>
										<div class="experience__area-right-skill-item-inner">
											<div class="experience__area-right-skill-item-bar" data-width="<?php echo esc_attr($settings['skill_lavel_1']); ?>"></div>
										</div>
									</div>
									<div class="experience__area-right-skill-item mt-20">
										<div class="experience__area-right-skill-item-content">
											<span class="text-two"><?php echo esc_html($settings['skill_2']); ?></span>
											<span class="experience__area-right-skill-item-count text-two"><span class="counter"><?php echo esc_attr($settings['skill_lavel_2']); ?></span><?php echo esc_html('%'); ?></span>
										</div>
										<div class="experience__area-right-skill-item-inner">
											<div class="experience__area-right-skill-item-bar" data-width="<?php echo esc_attr($settings['skill_lavel_2']); ?>"></div>
										</div>
									</div>
								</div>
								<a class="btn-two" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php if ('design-2' === $settings['select_design']) : ?>
			<div class="consulting__area">
			   <?php if ('yes' === $settings['theme_shape']) : ?>
				<img class="consulting__area-shape dark-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/consulting.png')); ?>" alt="shape4">
				<img class="consulting__area-shape light-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/consulting-dark.png')); ?>" alt="shape7">
				<?php endif;?>
				<div class="container">
					<div class="row align-items-center">
						<div class="col-xl-7 col-lg-6 lg-mb-30">
							<div class="consulting__area-image dark__image">
								<?php
								if ($image_one['url']) {
									if (!empty($image_one['alt'])) {
										echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
									} else {
										echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
									}
								}
								?>
							</div>
						</div>
						<div class="col-xl-5 col-lg-6">
							<div class="consulting__area-right">
								<div class="consulting__area-right-title">
									<span class="subtitle-two"><?php echo esc_html($settings['sub_title']); ?></span>
									<h2><?php echo esc_html($settings['title']); ?></h2>
									<p><?php echo esc_html($settings['description']); ?></p>
								</div>
								<div class="consulting__area-right-list">
									<span><i class="far fa-check"></i><?php echo esc_html($settings['item_one']); ?></span>
									<span><i class="far fa-check"></i><?php echo esc_html($settings['item_two']); ?></span>
								</div>
								<a class="btn-six" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php if ('design-3' === $settings['select_design']) : ?>
			<div class="chooseUs__area">
				<div class="container">
					<div class="row align-items-center mb-70">
						<div class="col-xl-6 col-lg-7 lg-mb-20">
							<div class="chooseUs__area-title">
								<span class="subtitle-three"><?php echo esc_html($settings['sub_title']); ?></span>
								<h2><?php echo esc_html($settings['title']); ?></h2>
							</div>
						</div>
						<div class="col-xl-6 col-lg-5">
							<div class="chooseUs__area-right">
								<div class="chooseUs__area-right-counter">
									<h1><span class="counter"><?php echo esc_html($settings['counter_point']); ?></span><?php echo esc_html('+'); ?></h1>
									<h6><?php echo esc_html($settings['counter_title']); ?></h6>
								</div>
								<?php if ('yes' === $settings['theme_shape']) : ?>
								<div class="chooseUs__area-right-shape">
									<img class="left-right-animate dark-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/choose-us.png')); ?>" alt="">
									<img class="left-right-animate light-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/choose-us-dark.png')); ?>" alt="">
								</div>
								<?php endif;?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-xl-6 xl-mb-30 dark__image">
							<?php
							if ($image_one['url']) {
								if (!empty($image_one['alt'])) {
									echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
								} else {
									echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
								}
							}
							?>
						</div>
						<div class="col-xl-6">
							<div class="row">
								<div class="col-sm-6 sm-mb-30">
									<div class="chooseUs__area-item">
										<?php if (!empty($settings['icon_one']['url'])) : ?>
											<div class="chooseUs__area-item-icon">
												<img src="<?php echo esc_url($settings['icon_one']['url']) ?>" alt="icon">
											</div>
										<?php endif; ?>
										<h4><?php echo esc_html($settings['item_one']); ?></h4>
										<p><?php echo esc_html($settings['desc_1']); ?></p>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="chooseUs__area-item">
										<?php if (!empty($settings['icon_two']['url'])) : ?>
											<div class="chooseUs__area-item-icon">
												<img src="<?php echo esc_url($settings['icon_two']['url']) ?>" alt="icon">
											</div>
										<?php endif; ?>
										<h4><?php echo esc_html($settings['item_two']); ?></h4>
										<p><?php echo esc_html($settings['desc_2']); ?></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php if ('design-4' === $settings['select_design']) : ?>
			<div class="company__two">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-xl-6 col-lg-7 lg-mb-30">
							<div class="company__two-left">
								<div class="company__two-left-title">
									<span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
									<h2><?php echo esc_html($settings['title']); ?></h2>
									<p><?php echo esc_html($settings['description']); ?></p>
								</div>
								<div class="company__two-left-skill">
									<div class="company__two-left-skill-item">
										<h2><span class="counter"><?php echo esc_html($settings['counter_point']); ?></span><?php echo esc_html('k'); ?></h2>
										<h6><?php echo esc_html($settings['counter_title']); ?></h6>
									</div>
									<div class="company__two-left-skill-item">
										<h2><span class="counter"><?php echo esc_html($settings['counter_point2']); ?></span><?php echo esc_html('k'); ?></h2>
										<h6><?php echo esc_html($settings['counter_title2']); ?></h6>
									</div>
								</div>
								<a class="btn-two" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
							</div>
						</div>
						<div class="col-xl-6 col-lg-5">
							<div class="company__two-right dark__image t-right">
								<?php
								if ($image_one['url']) {
									if (!empty($image_one['alt'])) {
										echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
									} else {
										echo '<img class="one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
									}
								}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

<?php
	}
}

Plugin::instance()->widgets_manager->register(new Why_US);
