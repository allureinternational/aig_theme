<?php

namespace Elementor;

use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH')) exit;

class Slider_Banner extends Widget_Base
{
    public function get_name()
    {
        return 'conbix-slider';
    }

    public function get_title()
    {
        return esc_html__('Slider Banner', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Banner', 'Slider', 'Home'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Banner Style', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select Banner Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Banner Style 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Banner Style 02', 'conbix-toolkit'),
                    'design-3' => esc_html__('Banner Style 03', 'conbix-toolkit'),
                    'design-4' => esc_html__('Banner Style 04', 'conbix-toolkit'),
                ],
                'default'      => 'design-4',
                'label_block'  => true,
            ]
        );

        $this->add_control(
            'theme_shape_img1',
            [
                'label' => esc_html__('Shape Image', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,               
            ]
        );

        $this->add_control(
            'theme_shape_img2',
            [
                'label' => esc_html__('Shape Image 2', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2'],
                ]
            ]
        );

        $this->add_control(
            'banner3_bg',
            [
                'label' => esc_html__('Banner BG', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );

        $this->add_control(
			'banner_arrow_enable',
			[
				'label'        => esc_html__( 'Show Arrow/Dots', 'conbix-toolkit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'conbix-toolkit' ),
				'label_off'    => esc_html__( 'No', 'conbix-toolkit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition' => [
                    'select_design' => ['design-2','design-3','design-4'],
                ]
			]
		);

        $this->end_controls_section();


        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Slider Content', 'conbix-toolkit'),
            ]
        );


        $banner_slider = new Repeater();

        $banner_slider->add_control(
            'slider_content',
            [
                'label'   => esc_html__('Select Slider Content for', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'slider-1' => esc_html__('Banner 01', 'conbix-toolkit'),
                    'slider-2' => esc_html__('Banner 02', 'conbix-toolkit'),
                    'slider-4' => esc_html__('Banner 04', 'conbix-toolkit'),
                ],
                'default'     => 'slider-4',
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_image',
            [
                'label' => esc_html__('Choose Image', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_tag',
            [
                'label'   => esc_html__('Slider Tag', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'condition' => [
                    'slider_content' => ['slider-2'],
                ]
            ]
        );

        $banner_slider->add_control(
            'slider_subtitle',
            [
                'label'   => esc_html__('Sub Title', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_title',
            [
                'label'   => esc_html__('Title', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_description',
            [
                'label'   => esc_html__('Content', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'condition' => [
                    'slider_content' => ['slider-1'],
                ]
            ]
        );

        $banner_slider->add_control(
            'slider_btn_text',
            [
                'label' => esc_html__('Button Text', 'conbix-toolkit'),
                'type'  => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_btn_url',
            [
                'label' => esc_html__('Button URL', 'conbix-toolkit'),
                'type'  => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_btn_two_text',
            [
                'label' => esc_html__('Button Two Text', 'conbix-toolkit'),
                'type'  => Controls_Manager::TEXT,
                'label_block' => true,
                'condition' => [
                    'slider_content' => ['slider-1'],
                ]
            ]
        );

        $banner_slider->add_control(
            'slider_btn_two_url',
            [
                'label' => esc_html__('Button Two URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'condition' => [
                    'slider_content' => ['slider-1'],
                ]
            ]
        );

        $banner_slider->add_control(
            'slider_video_url',
            [
                'label' => esc_html__('Video URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'condition' => [
                    'slider_content' => ['slider-4'],
                ],
            ]
        );



        $this->add_control(
            'banner_slides',
            [
                'label' => esc_html__('Banner Slides', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $banner_slider->get_controls(),
                'default' => [
                    [
                        'slider_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'slider_tag'          => esc_html__('Conbix', 'conbix-toolkit'),
                        'slider_subtitle'     => esc_html__('Welcome to Conbix', 'conbix-toolkit'),
                        'slider_title'        => esc_html__('Business consulting advice', 'conbix-toolkit'),
                        'slider_description'  => esc_html__('We help small startups grow from idea to millions of users', 'conbix-toolkit'),
                        'slider_btn_text'     => esc_html__('Read More', 'conbix-toolkit'),
                        'slider_btn_two_text' => esc_html__('Read More', 'conbix-toolkit'),
                        'slider_btn_url'      => esc_attr__('http://google.com', 'conbix-toolkit'),
                        'slider_btn_two_url'  => esc_attr__('http://google.com', 'conbix-toolkit'),
                        'slider_video_url'    => esc_attr__('https://www.youtube.com/watch?v=SZEflIVnhH8', 'conbix-toolkit'),
                    ],

                    [
                        'slider_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'slider_tag'          => esc_html__('Conbix', 'conbix-toolkit'),
                        'slider_subtitle'     => esc_html__('Welcome to Conbix', 'conbix-toolkit'),
                        'slider_title'        => esc_html__('Business consulting advice', 'conbix-toolkit'),
                        'slider_description'  => esc_html__('We help small startups grow from idea to millions of users', 'conbix-toolkit'),
                        'slider_btn_text'     => esc_html__('Read More', 'conbix-toolkit'),
                        'slider_btn_two_text' => esc_html__('Read More', 'conbix-toolkit'),
                        'slider_btn_url'      => esc_attr__('http://google.com', 'conbix-toolkit'),
                        'slider_btn_two_url'  => esc_attr__('http://google.com', 'conbix-toolkit'),
                        'slider_video_url'    => esc_attr__('https://www.youtube.com/watch?v=SZEflIVnhH8', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ slider_subtitle }}}',

                'condition' => [
                    'select_design!' => 'design-3',
                ],
            ]
        );


        $this->add_control(
            'slider_subtitle_4',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Welcome Our Conbix', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );
        $this->add_control(
            'slider_title_4',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Business Expert Consultants', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );
        $this->add_control(
            'slider_desc_4',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('We are experts in Consulting business development', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );
        $this->add_control(
            'slider_btn_4',
            [
                'label' => esc_html__('Button Text', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );
        $this->add_control(
            'slider_btnurl_4',
            [
                'label' => esc_html__('Button URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_attr__('http://google.com', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );
        $this->add_control(
            'slider_video_4',
            [
                'label' => esc_html__('Video Button Text', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Watch the Consulting Video', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );
        $this->add_control(
            'slider_videourl_4',
            [
                'label' => esc_html__('Video URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_attr__('https://www.youtube.com/watch?v=SZEflIVnhH8', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );

        $image_slide = new Repeater();

        $image_slide->add_control(
            'gallery_slider_img',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => esc_html__('Image', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'gallery_slider',
            [
                'label' => esc_html__('Slider Images', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $image_slide->get_controls(),
                'default' => [
                    [
                        'gallery_slider_img' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'gallery_slider_img' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],

                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ],
                'title_field' => esc_html__('Slide Image', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $theme_shape_img1 = $settings['theme_shape_img1'];
        $theme_shape_img2 = $settings['theme_shape_img2'];
        $banner3_bg = $settings['banner3_bg'];

?>
        <?php if ('design-1' === $settings['select_design'] && !empty($settings['banner_slides'])) : ?>
            <!-- Start Banner Style 01 -->
            <div class="banner__one swiper banner-slider">
                <div class="swiper-wrapper">
                    <?php foreach ($settings['banner_slides'] as $slide) : ?>
                        <div class="banner__one-image swiper-slide" style="background-image: url(<?php echo esc_url($slide['slider_image']['url']) ?>)">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="banner__one-content">
                                            <span data-animation="fadeInUp" data-delay=".4s"><?php echo esc_html($slide['slider_subtitle']); ?></span>
                                            <h1 data-animation="fadeInUp" data-delay=".6s"><?php echo esc_html($slide['slider_title']); ?></h1>
                                            <p data-animation="fadeInUp" data-delay=".8s"><?php echo esc_html($slide['slider_description']); ?></p>
                                            <div class="banner__one-content-button" data-animation="fadeInUp" data-delay="1s">
                                                <div class="banner__one-content-button-item">
                                                    <a class="btn-one" href="<?php echo esc_url($slide['slider_btn_url']); ?>"><?php echo esc_html($slide['slider_btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
                                                </div>
                                                <div class="banner__one-content-button-item">
                                                    <a class="btn-three" href="<?php echo esc_url($slide['slider_btn_two_url']); ?>"><?php echo esc_html($slide['slider_btn_two_text']); ?><i class="far fa-chevron-double-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- End Banner Style 01 -->
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design'] && !empty($settings['banner_slides'])) : ?>
            <!-- Start Banner Style 02 -->
            <div class="banner__two swiper banner-slider">
                <div class="swiper-wrapper">
                    <?php foreach ($settings['banner_slides'] as $slide) : ?>
                        <div class="banner__two-image swiper-slide" style="background-image: url(<?php echo esc_url($slide['slider_image']['url']) ?>)">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="banner__two-content">
                                            <b class="subtitle"><?php echo esc_html($slide['slider_tag']); ?></b>
                                            <span data-animation="fadeInUp" data-delay=".3s"><?php echo esc_html($slide['slider_subtitle']); ?></span>
                                            <h1 data-animation="fadeInUp" data-delay=".7s"><?php echo esc_html($slide['slider_title']); ?></h1>
                                            <div class="banner__two-content-button" data-animation="fadeInUp" data-delay="1s">
                                                <a class="btn-five" href="<?php echo esc_url($slide['slider_btn_url']); ?>"><?php echo esc_html($slide['slider_btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
                                            </div>
                                            <?php if(!empty($theme_shape_img1['url'])) : ?>
                                            <img class="banner__two-image-shape-one" src="<?php echo esc_url($theme_shape_img1['url']);?>" data-animation="rollIn" data-delay="2s" alt="shape">
                                            <?php endif;?>
                                        </div>
                                        <?php if(!empty($theme_shape_img2['url'])) : ?>
                                        <img class="banner__two-image-shape-two" src="<?php echo esc_url($theme_shape_img2['url']);?>" data-animation="fadeInRightBig" data-delay="1.1s" alt="shape">
                                        <?php endif;?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if ('yes' === $settings['banner_arrow_enable']) : ?>
                <div class="banner__two-arrow">
                    <div class="banner__two-arrow-prev conbix-button-prev"><i class="fal fa-long-arrow-left"></i></div>
                    <div class="banner__two-arrow-next conbix-button-next"><i class="fal fa-long-arrow-right"></i></div>
                </div>
                <?php endif; ?>
            </div>
            <!-- End Banner Style 02 -->
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']) : ?>
            <!-- Start Banner Style 03 -->
            <div class="banner__three" <?php if(!empty($banner3_bg['url'])) : ?>style="background-image:url('<?php echo esc_url($banner3_bg['url']);?>')"<?php endif;?>>
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-5 col-lg-6 lg-mb-30">
                            <div class="banner__three-title">
                                <span><?php echo esc_html($settings['slider_subtitle_4']); ?></span>
                                <h1><?php echo esc_html($settings['slider_title_4']); ?></h1>
                                <p><?php echo esc_html($settings['slider_desc_4']); ?></p>
                                <div class="banner__three-title-bottom">
                                    <div class="banner__three-title-bottom-btn">
                                        <a class="btn-seven" href="<?php echo esc_url($settings['slider_btnurl_4']); ?>"><?php echo esc_html($settings['slider_btn_4']); ?><i class="far fa-chevron-double-right"></i></a>
                                    </div>
                                    <div class="banner__three-title-bottom-video">
                                        <div class="banner__three-title-bottom-video-icon">
                                            <a class="video-popup" href="<?php echo esc_url($settings['slider_videourl_4']); ?>"><i class="fal fa-play"></i></a>
                                        </div>
                                        <h6><?php echo esc_html($settings['slider_video_4']); ?></h6>
                                    </div>
                                </div>
                                <?php if ('yes' === $settings['banner_arrow_enable']) : ?>
                                <div class="swiper-pagination"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-6">
                            <?php if (!empty($settings['gallery_slider'])) : ?>
                                <div class="swiper banner__three__slider banner__three-image dark__image">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($settings['gallery_slider'] as $image) : ?>
                                            <div class="swiper-slide">
                                                <img src="<?php echo esc_url($image['gallery_slider_img']['url']); ?>" alt="slider">
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Banner Style 03 -->
        <?php endif; ?>

        <?php if ('design-4' === $settings['select_design'] && !empty($settings['banner_slides'])) : ?>
            <!-- Start Banner Style 04 -->
            <div class="banner__four swiper banner-slider">
                <div class="swiper-wrapper">
                    <?php foreach ($settings['banner_slides'] as $slide) : ?>
                        <div class="banner__four-image swiper-slide" style="background-image: url(<?php echo esc_url($slide['slider_image']['url']) ?>)">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="banner__four-content">
                                            <span data-animation="fadeInUp" data-delay=".4s"><?php echo esc_html($slide['slider_subtitle']); ?></span>
                                            <h1 data-animation="fadeInUp" data-delay=".7s"><?php echo esc_html($slide['slider_title']); ?></h1>
                                            <div class="banner__four-content-button" data-animation="fadeInUp" data-delay="1s">
                                                <div class="banner__four-content-button-item">
                                                    <a class="btn-one" href="<?php echo esc_url($slide['slider_btn_url']); ?>"><?php echo esc_html($slide['slider_btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
                                                </div>
                                                <div class="banner__four-content-video-icon">
                                                    <a class="video-popup" href="<?php echo esc_url($slide['slider_video_url']); ?>"><i class="fas fa-play"></i></a>
                                                </div>
                                            </div>
                                            <?php if ('yes' === $settings['banner_arrow_enable']) : ?>
                                            <div class="banner-pagination"></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- End Banner Style 04 -->
        <?php endif; ?>
        <?php if ('design-1' === $settings['select_design'] || 'design-3' === $settings['select_design'] || 'design-4' === $settings['select_design']) : ?>
        <style>
            <?php if (!empty($theme_shape_img1['url'])): ?>
        .banner__four-image::after,
        .banner__one-image::after,
        .banner__three .swiper-pagination .swiper-pagination-bullet-active::before {
            background-image: url("<?php echo esc_url($theme_shape_img1['url']);?>");
        }
        <?php endif; ?>
        </style>
        <?php endif; ?>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Slider_Banner);
