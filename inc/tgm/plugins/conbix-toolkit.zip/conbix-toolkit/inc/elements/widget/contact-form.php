<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Contact_Form extends Widget_Base
{
    public function get_name()
    {
        return 'contact-form';
    }

    public function get_title()
    {
        return esc_html__('Contact Form', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Contact', 'Form', 'us'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Design', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select a Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Style 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Style 02', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'wpcf7_form_list',
            [
                'label'       => esc_html__('Select Contact Form', 'conbix-toolkit'),
                'label_block' => true,
                'type'        => Controls_Manager::SELECT,
                'options'     => $this->conbix_contact_form(),
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Get in Touch', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Get In Touch', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $contact = new Repeater();

        $contact->add_control(
            'meta_name',
            [
                'label'   => esc_html__('Name', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $contact->add_control(
            'meta_content',
            [
                'label'   => esc_html__('Content', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'contacts',
            [
                'label' => esc_html__('Contact Info', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $contact->get_controls(),
                'default' => [
                    [
                        'meta_name'     => esc_html__('Phone:', 'conbix-toolkit'),
                        'meta_content'  => esc_attr__('+910934034034', 'conbix-toolkit'),
                    ],

                    [
                        'meta_name'     => esc_html__('Email:', 'conbix-toolkit'),
                        'meta_content'  => esc_attr__('hello.conbix@gmail.com', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ meta_name }}}',
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );


        $this->end_controls_section();
    }
    protected function conbix_contact_form()
    {

        if (!class_exists('WPCF7_ContactForm')) {
            return array();
        }

        $forms = \WPCF7_ContactForm::find(array(
            'orderby' => 'title',
            'order'   => 'ASC',
        ));

        if (empty($forms)) {
            return array();
        }

        $result = array();

        foreach ($forms as $item) {
            $key            = sprintf('%1$s::%2$s', $item->id(), $item->title());
            $result[$key] = $item->title();
        }

        return $result;
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $conbix_htmls = array(
            'a'      => array(
                'href'   => array(),
                'target' => array()
            ),
            'span'   => array(),
        );

?>
        <?php if ('design-1' === $settings['select_design']) : ?>
            <div class="contact__page section-padding pb-0">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 col-lg-5 order-last order-lg-first">
                            <div class="contact__page-form">
                                <?php echo do_shortcode('[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]'); ?>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7 lg-mb-30">
                            <div class="contact__page-info">
                                <h2 class="mb-60 lg-mb-30"><?php echo esc_html($settings['title']); ?></h2>
                                <?php foreach ($settings['contacts'] as $item) : ?>
                                    <div class="contact__page-info-item">
                                        <h6><?php echo wp_kses($item['meta_name'], $conbix_htmls); ?></h6>
                                        <span><?php echo wp_kses($item['meta_content'], $conbix_htmls); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <div class="contact__four">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
                    <div class="contact__four-form t-center">
                        <div class="contact__four-form-title">	
                            <span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
                            <h2><?php echo esc_html($settings['title']); ?></h2>
                        </div>
                        <?php echo do_shortcode('[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]'); ?>
                    </div>
				</div>
			</div>
		</div>
	</div>
        <?php endif; ?>

<?php
    }
}

Plugin::instance()->widgets_manager->register(new Contact_Form);
