<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Section_Title extends Widget_Base
{
    public function get_name()
    {
        return 'section-title';
    }

    public function get_title()
    {
        return esc_html__('Section Title', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Title', 'Section', 'Content'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Alignment', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select a Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Style 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Style 02', 'conbix-toolkit'),
                    'design-3' => esc_html__('Style 03', 'conbix-toolkit'),
                    'design-4' => esc_html__('Style 04', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );

        $this->add_control(
            'alignment',
            [
                'label'   => esc_html__('Content Alignment', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'left'   => esc_html__('Left', 'conbix-toolkit'),
                    'center' => esc_html__('Center', 'conbix-toolkit'),
                    'right'  => esc_html__('Right', 'conbix-toolkit'),
                ],
                'default'      => 'center',
                'label_block'  => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('About', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('We are best Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $alignment = $settings['alignment'];

?>
        <?php if ('design-1' === $settings['select_design']) : ?>
            <div class="team__area-title t-<?php echo esc_attr($alignment); ?>">
                <span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
                <h2><?php echo esc_html($settings['title']); ?></h2>
            </div>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <div class="team__area-title t-<?php echo esc_attr($alignment); ?>">
                <span class="subtitle-two"><?php echo esc_html($settings['sub_title']); ?></span>
                <h2><?php echo esc_html($settings['title']); ?></h2>
            </div>
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']) : ?>
            <div class="team__area-title t-<?php echo esc_attr($alignment); ?>">
                <span class="subtitle-three"><?php echo esc_html($settings['sub_title']); ?></span>
                <h2><?php echo esc_html($settings['title']); ?></h2>
            </div>
        <?php endif; ?>

        <?php if ('design-4' === $settings['select_design']) : ?>
            <div class="services__three-title t-<?php echo esc_attr($alignment); ?>">
                <span class="subtitle-three"><?php echo esc_html($settings['sub_title']); ?></span>
                <h2><?php echo esc_html($settings['title']); ?></h2>
            </div>
        <?php endif; ?>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Section_Title);
