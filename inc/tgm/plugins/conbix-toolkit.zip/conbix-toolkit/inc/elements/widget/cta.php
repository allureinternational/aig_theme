<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Call_To_Action extends Widget_Base
{
    public function get_name()
    {
        return 'cta';
    }

    public function get_title()
    {
        return esc_html__('CTA - Call to Action', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'cta', 'action', 'call'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Design', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select a Design', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Design 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Design 02', 'conbix-toolkit'),
                    'design-3' => esc_html__('Design 03', 'conbix-toolkit'),
                    'design-4' => esc_html__('Design 04', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );

        $this->add_control(
            'bg_color',
            [
                'label' => esc_html__('BG Color', 'conbix-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta__area::before' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'bg_image',
            [
                'label' => esc_html__('BG Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design!' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'shape_one',
            [
                'label' => esc_html__('Shape Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'select_design' => ['design-3', 'design-4'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('CTA', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design!' => ['design-3'],
                ],
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('We are best call to actions', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'wpcf7_form_list',
            [
                'label'       => esc_html__('Select Contact Form', 'conbix-toolkit'),
                'label_block' => true,
                'type'        => Controls_Manager::SELECT,
                'options'     => $this->conbix_contact_form(),
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button Text', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3', 'design-2'],
                ],
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('Button URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_attr__('http://google.com', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-3', 'design-2'],
                ],
            ]
        );


        $this->add_control(
            'content_other',
            [
                'label' => esc_html__('Video Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Watch The Consulting Video', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );

        $this->add_control(
            'video_url',
            [
                'label' => esc_html__('Video URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_attr__('https://www.youtube.com/watch?v=SZEflIVnhH8', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'contact_items',
            [
                'label' => esc_html__('Email & Phone', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-4'],
                ],
            ]
        );

        $this->add_control(
            'phone_title',
            [
                'label' => esc_html__('Phone Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Call us 24/7', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'user_phone',
            [
                'label' => esc_html__('Phone Number', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('+012 652 689 523', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'phone_url',
            [
                'label' => esc_html__('Phone URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('tel:+012652689523', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'mail_title',
            [
                'label' => esc_html__('Email Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Mail us anytime', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'user_mail',
            [
                'label' => esc_html__('Your Email', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('conbix@gmail.com', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'mail_url',
            [
                'label' => esc_html__('Mail URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('mailto:conbix@gmail.com', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();
    }
    protected function conbix_contact_form()
    {

        if (!class_exists('WPCF7_ContactForm')) {
            return array();
        }

        $forms = \WPCF7_ContactForm::find(array(
            'orderby' => 'title',
            'order'   => 'ASC',
        ));

        if (empty($forms)) {
            return array();
        }

        $result = array();

        foreach ($forms as $item) {
            $key            = sprintf('%1$s::%2$s', $item->id(), $item->title());
            $result[$key] = $item->title();
        }

        return $result;
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

?>
        <?php if ('design-1' === $settings['select_design']) : ?>
            <div class="cta__area">
                <div class="container">
                    <div class="row cta__area-bg align-items-center">
                        <div class="col-xxl-5 col-xl-4">
                            <div class="cta__area-title">
                                <h2><?php echo esc_html($settings['title']); ?></h2>
                                <span class="text-two"><?php echo esc_html($settings['sub_title']); ?></span>
                            </div>
                        </div>
                        <div class="col-xxl-7 col-xl-8 pr-0">
                            <?php if (!empty($settings['wpcf7_form_list'])) : ?>
                                <div class="cta__area-form">
                                    <?php echo do_shortcode('[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <div class="solution__area section-padding" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']) ?>)">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-9">
                            <div class="solution__area-title">
                                <span class="subtitle-two"><?php echo esc_html($settings['sub_title']); ?></span>
                                <h1><?php echo esc_html($settings['title']); ?></h1>
                                <?php if (!empty($settings['btn_url'])) : ?>
                                    <a class="btn-five" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-xl-3">
                            <div class="solution__area-right">
                                <div class="solution__area-right-video">
                                    <div class="solution__area-right-icon video video-pulse">
                                        <a class="video-popup" href="<?php echo esc_url($settings['video_url']); ?>"><i class="fal fa-play"></i></a>
                                    </div>
                                    <h6><?php echo esc_html($settings['content_other']); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']) : ?>
            <div class="about__solution" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']) ?>)">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-8">
                            <div class="about__solution-left xl-t-center">
                                <h2><?php echo esc_html($settings['title']); ?></h2>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="about__solution-right t-right xl-t-center">
                                <?php if (!empty($settings['btn_url'])) : ?>
                                    <a class="btn-one" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
                                <?php endif; ?>
                                <?php if (!empty($settings['shape_one']['url'])) : ?>
                                    <img class="about__solution-right-shape left-right-animate" src="<?php echo esc_url($settings['shape_one']['url']) ?>" alt="shape one">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-4' === $settings['select_design']) : ?>
            <div class="cta__two" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']) ?>)">
                <?php if (!empty($settings['shape_one']['url'])) : ?>
                    <img class="cta__two-shape left-right-animate2" src="<?php echo esc_url($settings['shape_one']['url']) ?>" alt="shape one">
                <?php endif; ?>
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-6 col-lg-5 lg-mb-30">
                            <div class="cta__two-title">
                                <span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
                                <h2><?php echo esc_html($settings['title']); ?></h2>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-7">
                            <div class="cta__two-info">
                                <div class="cta__two-info-item">
                                    <div class="cta__two-info-item-icon">
                                        <i class="fal fa-phone-alt icon-animation"></i>
                                    </div>
                                    <div>
                                        <span><?php echo esc_html($settings['phone_title']); ?></span>
                                        <h6><a href="<?php echo esc_url($settings['phone_url']); ?>"><?php echo esc_html($settings['user_phone']); ?></a></h6>
                                    </div>
                                </div>
                                <div class="cta__two-info-item">
                                    <div class="cta__two-info-item-icon">
                                        <i class="fal fa-envelope"></i>
                                    </div>
                                    <div>
                                        <span><?php echo esc_html($settings['mail_title']); ?></span>
                                        <h6><a href="<?php echo esc_url($settings['mail_url']); ?>"><?php echo esc_html($settings['user_mail']); ?></a></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Call_To_Action);
