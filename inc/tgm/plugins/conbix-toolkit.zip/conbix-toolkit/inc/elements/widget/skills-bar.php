<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Skills_Bar extends Widget_Base
{
    public function get_name()
    {
        return 'skill-bar';
    }

    public function get_title()
    {
        return esc_html__('Skill Bar', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Skills', 'bar', 'skill bar'];
    }

    protected function register_controls()

    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );
        $portfolio_meta = new Repeater();

        $portfolio_meta->add_control(
            'skill_title',
            [
                'label'   => esc_html__('Skill Title', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $portfolio_meta->add_control(
            'skill_lavel',
            [
                'label'   => esc_html__('Skill Lavel', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'skills_list',
            [
                'label' => esc_html__('Skills List', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $portfolio_meta->get_controls(),
                'default' => [
                    [
                        'skill_title'  => esc_html__('Web Development', 'conbix-toolkit'),
                        'skill_lavel'  => esc_html__('70', 'conbix-toolkit'),
                    ],

                    [
                        'skill_title'  => esc_html__('Graphic Design', 'conbix-toolkit'),
                        'skill_lavel'  => esc_html__('90', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ skill_title }}}',
            ]
        );

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

?>
        <?php foreach ($settings['skills_list'] as $key => $item) : ?>
            <div class="team__details-skills-item<?php echo $key === 0 ? '' : ' mt-25'; ?>">
                <div class="team__details-skills-item-content">
                    <h6><?php echo esc_html($item['skill_title']); ?></h6>
                    <span class="team__details-skills-item-count text-two"><span class="counter"><?php echo esc_attr($item['skill_lavel']); ?></span><?php echo esc_html('%'); ?></span>
                </div>
                <div class="team__details-skills-item-inner">
                    <div class="team__details-skills-item-bar" data-width="<?php echo esc_html($item['skill_lavel']); ?>"></div>
                </div>
            </div>
        <?php endforeach; ?>

<?php
    }
}

Plugin::instance()->widgets_manager->register(new Skills_Bar);
