<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Features extends Widget_Base
{
    public function get_name()
    {
        return 'features';
    }

    public function get_title()
    {
        return esc_html__('Features', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Icon Box', 'Feature', 'Content'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Design', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select a Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Design 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Design 02', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );

        $this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon BG', 'conbix-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .solutions__two-item-icon' => 'background: {{VALUE}}',
				],
                'condition' => [
                    'select_design' => ['design-2'],
                ],
			]
		);


        $this->end_controls_section();

        $this->start_controls_section(
            'section_head',
            [
                'label' => esc_html__('Heading Content', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Advance Solutions', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('We help for Planing', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Features Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'heading_1',
            [
                'label' => esc_html__('Content One', 'conbix-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'image_1',
            [
                'label' => esc_html__('Image Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );

        $this->add_control(
            'title_1',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Business Essentials', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'desc_1',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'heading_2',
            [
                'label' => esc_html__('Content Two', 'conbix-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'image_2',
            [
                'label' => esc_html__('Image Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );

        $this->add_control(
            'title_2',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Business strategy', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'desc_2',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'heading_3',
            [
                'label' => esc_html__('Content Three', 'conbix-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'image_3',
            [
                'label' => esc_html__('Image Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );

        $this->add_control(
            'title_3',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Financial planning', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_3',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $image1 = $settings['image_1'];
        $image2 = $settings['image_2'];
        $image3 = $settings['image_3'];

?>
        <?php if ('design-1' === $settings['select_design']) : ?>
            <div class="features">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="features-area">
                                <div class="features-area-item ltb-radius">
                                    <span><i class="far fa-arrow-right"></i></span>
                                    <h4><?php echo esc_html($settings['title_1']); ?></h4>
                                    <p><?php echo esc_html($settings['desc_1']); ?></p>
                                </div>
                                <div class="features-area-item features-area-item-hover">
                                    <span><i class="far fa-arrow-right"></i></span>
                                    <h4><?php echo esc_html($settings['title_2']); ?></h4>
                                    <p><?php echo esc_html($settings['desc_2']); ?></p>
                                </div>
                                <div class="features-area-item rtb-radius">
                                    <span><i class="far fa-arrow-right"></i></span>
                                    <h4><?php echo esc_html($settings['title_3']); ?></h4>
                                    <p><?php echo esc_html($settings['desc_3']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <div class="solutions__twox">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-6 lg-mb-30">
                            <div class="solutions__two-title">
                                <span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
                                <h2><?php echo esc_html($settings['title']); ?></h2>
                                <p><?php echo esc_html($settings['desc']); ?></p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 xl-mb-30">
                            <div class="solutions__two-item">
                                <div class="solutions__two-item-icon">
                                <?php
                                    if ($image1['url']) {
                                        if (!empty($image1['alt'])) {
                                            echo '<img src="' . esc_url($image1['url']) . '" alt="' . esc_attr($image1['alt']) . '" />';
                                        } else {
                                            echo '<img src="' . esc_url($image1['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                        }
                                    } ?>
                                </div>
                                <h4><?php echo esc_html($settings['title_1']); ?></h4>
                                <p><?php echo esc_html($settings['desc_1']); ?></p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 md-mb-30">
                            <div class="solutions__two-item">
                                <div class="solutions__two-item-icon">
                                <?php
                                        if ($image2['url']) {
                                            if (!empty($image2['alt'])) {
                                                echo '<img src="' . esc_url($image2['url']) . '" alt="' . esc_attr($image2['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image2['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                            }
                                        } ?>
                                </div>
                                <h4><?php echo esc_html($settings['title_2']); ?></h4>
                                <p><?php echo esc_html($settings['desc_2']); ?></p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="solutions__two-item">
                                <div class="solutions__two-item-icon">
                                <?php
                                        if ($image3['url']) {
                                            if (!empty($image3['alt'])) {
                                                echo '<img src="' . esc_url($image3['url']) . '" alt="' . esc_attr($image3['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image3['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                            }
                                        } ?>
                                </div>
                                <h4><?php echo esc_html($settings['title_3']); ?></h4>
                                <p><?php echo esc_html($settings['desc_3']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Features);
