<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if (!defined('ABSPATH')) exit;

class Testimonials extends Widget_Base
{
    public function get_name()
    {
        return 'testimonials';
    }

    public function get_title()
    {
        return esc_html__('Testimonial', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Client', 'Testimonial', 'Review'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Testimonial Style', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select Testimonial Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Testimonial 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Testimonial 02', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );

        $this->add_control(
			'theme_shape',
			[
				'label'        => esc_html__( 'Element Shapes', 'conbix-toolkit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'conbix-toolkit' ),
				'label_off'    => esc_html__( 'Hide', 'conbix-toolkit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition' => [
					'select_design' => ['design-1'],
				],
			]
		);

        $this->add_control(
            'quote_icon',
            [
                'label' => esc_html__('Choose Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_head',
            [
                'label' => esc_html__('Testimonial Heading', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'show_head',
            [
                'label' => esc_html__('Show Heading', 'conbix-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'conbix-toolkit'),
                'label_off' => esc_html__('No', 'conbix-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Testimonial', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'show_head'     => ['yes'],
                    'select_design' => ['design-1'],
                ],
            ]
        );
        $this->add_control(
            'title_one',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('What People say about Us', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'show_head'     => ['yes'],
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Testimonial Content', 'conbix-toolkit'),
            ]
        );


        $testimonial_item = new Repeater();

        $testimonial_item->add_control(
            'test_image',
            [
                'label' => esc_html__('Author Image', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $testimonial_item->add_control(
            'test_title',
            [
                'label'   => esc_html__('Author Name', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $testimonial_item->add_control(
            'test_subtitle',
            [
                'label'   => esc_html__('Author Position', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $testimonial_item->add_control(
            'test_description',
            [
                'label'   => esc_html__('Write Content', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $testimonial_item->add_control(
            'service_type',
            [
                'label'   => esc_html__('Service Type', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'testimonial_items',
            [
                'label' => esc_html__('Testimonial Slides', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $testimonial_item->get_controls(),
                'default' => [
                    [
                        'test_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'test_subtitle'     => esc_html__('Web Designer', 'conbix-toolkit'),
                        'test_title'        => esc_html__('Sara Albert', 'conbix-toolkit'),
                        'service_type'      => esc_html__('Item Support', 'conbix-toolkit'),
                        'test_description'  => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'conbix-toolkit'),
                    ],
                    [
                        'test_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'test_subtitle'     => esc_html__('Ui/Ux Designer', 'conbix-toolkit'),
                        'test_title'        => esc_html__('James Millard', 'conbix-toolkit'),
                        'service_type'      => esc_html__('Code Quality', 'conbix-toolkit'),
                        'test_description'  => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'conbix-toolkit'),
                    ],
                    [
                        'test_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'test_subtitle'     => esc_html__('Developer', 'conbix-toolkit'),
                        'test_title'        => esc_html__('Richerd William', 'conbix-toolkit'),
                        'service_type'      => esc_html__('Design Quality', 'conbix-toolkit'),
                        'test_description'  => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ test_title }}}',
            ]
        );



        $this->end_controls_section();
    }


    protected function render()
    {
        $settings   = $this->get_settings_for_display();
        $quote_icon = $settings['quote_icon'];

?>
        <?php if ('design-1' === $settings['select_design'] && !empty($settings['testimonial_items'])) : ?>
            <div class="testimonial__area">
                <?php if ('yes' === $settings['theme_shape']) : ?>
                    <img class="testimonial__area-shape dark-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/about.png')); ?>" alt="shape">
                    <img class="testimonial__area-shape light-n" src="<?php echo esc_url(get_theme_file_uri('assets/img/shape/about-dark.png')); ?>" alt="shape-dark">
                <?php endif; ?>
                <div class="container">
                    <?php if ('yes' === $settings['show_head']) : ?>
                        <div class="row mb-70 align-items-end">
                            <div class="col-xl-8 col-lg-8 lg-mb-30">
                                <div class="testimonial__area-title lg-t-center">
                                    <span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
                                    <h2><?php echo esc_html($settings['title_one']); ?></h2>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                                <div class="testimonial__area-button t-right lg-t-center">
                                    <div class="testimonial__area-button-prev conbix-button-prev"><i class="fal fa-long-arrow-left"></i></div>
                                    <div class="testimonial__area-button-next conbix-button-next"><i class="fal fa-long-arrow-right"></i></div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="swiper testimonial__area-slider">
                                <div class="swiper-wrapper">
                                    <?php foreach ($settings['testimonial_items'] as $slide) : ?>
                                        <div class="testimonial__area-item swiper-slide">
                                            <div class="testimonial__area-item-client">
                                                <div class="testimonial__area-item-icon">
                                                    <i class="fal fa-quote-right"></i>
                                                </div>
                                                <div class="testimonial__area-item-client-image">
                                                    <img src="<?php echo esc_url($slide['test_image']['url']) ?>" alt="client">
                                                </div>
                                                <div class="testimonial__area-item-client-title">
                                                    <h5><?php echo esc_html($slide['test_title']); ?></h5>
                                                    <span class="text-eight"><?php echo esc_html($slide['test_subtitle']); ?></span>
                                                </div>
                                            </div>
                                            <p><?php echo esc_html($slide['test_description']); ?></p>
                                            <div class="testimonial__area-item-reviews">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if ('design-2' === $settings['select_design'] && !empty($settings['testimonial_items'])) : ?>
            <div class="testimonial__two">
                <div class="container">
                    <div class="row">
                        <?php foreach ($settings['testimonial_items'] as $slide) : ?>
                            <div class="col-xl-4 col-md-6">
                                <div class="testimonial__two-item mb-25">
                                    <div class="testimonial__two-item-top">
                                        <?php
                                        if ($quote_icon['url']) {
                                            if (!empty($quote_icon['alt'])) {
                                                echo '<img src="' . esc_url($quote_icon['url']) . '" alt="' . esc_attr($quote_icon['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($quote_icon['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                            }
                                        } ?>
                                        <div class="testimonial__two-item-top-reviews">
                                            <h6><?php echo esc_html($slide['service_type']); ?></h6>
                                            <ul>
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <p><?php echo esc_html($slide['test_description']); ?></p>
                                    <div class="testimonial__two-item-bottom">
                                        <img src="<?php echo esc_url($slide['test_image']['url']) ?>" alt="client">
                                        <div class="testimonial__two-item-bottom-name">
                                            <h5><?php echo esc_html($slide['test_title']); ?></h5>
                                            <span><?php echo esc_html($slide['test_subtitle']); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Testimonials);
