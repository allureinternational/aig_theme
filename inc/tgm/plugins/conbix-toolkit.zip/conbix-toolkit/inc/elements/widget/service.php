<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;

if (!defined('ABSPATH')) exit;

class Services extends Widget_Base
{
    public function get_name()
    {
        return 'service';
    }

    public function get_title()
    {
        return esc_html__('Services', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Title', 'Section', 'Content'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Options', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select a Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Design 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Design 02', 'conbix-toolkit'),
                    'design-3' => esc_html__('Design 03', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );

        $this->add_control(
            'columns_desktop',
            [
                'label'   => esc_html__('Columns On Desktop', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'col-xl-6' => esc_html__('Column 2', 'conbix-toolkit'),
                    'col-xl-4' => esc_html__('Column 3', 'conbix-toolkit'),
                    'col-xl-3' => esc_html__('Column 4', 'conbix-toolkit'),
                ],
                'default'      => 'col-xl-4',
                'label_block'  => true,
                'condition' => [
                    'select_design' => ['design-1','design-3'],
                ],
            ]
        );

        $this->add_control(
            'columns_tab',
            [
                'label'   => esc_html__('Columns On Tablet', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'col-lg-12' => esc_html__('1 Column', 'conbix-toolkit'),
                    'col-lg-6'  => esc_html__('2 Column', 'conbix-toolkit'),
                ],
                'default'      => 'col-lg-6',
                'label_block'  => true,
                'condition' => [
                    'select_design' => ['design-1','design-3'],
                ],
            ]
           
        );


        $this->add_control(
            'active_slider',
            [
                'label' => esc_html__('Enable Slider', 'conbix-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'conbix-toolkit'),
                'label_off' => esc_html__('No', 'conbix-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'show_head'     => ['yes'],
                    'select_design' => ['design-3'],
                ],
            ]
        );

        $this->add_control(
            'show_arrow',
            [
                'label' => esc_html__('Show Arrow', 'conbix-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'conbix-toolkit'),
                'label_off' => esc_html__('No', 'conbix-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'show_head'     => ['yes'],
                    'select_design' => ['design-2', 'design-3'],
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'service_head',
            [
                'label' => esc_html__('Service Heading', 'conbix-toolkit'),
                'condition' => [
                    'select_design!' => ['design-3'],
                ],
            ]
           
        );

        $this->add_control(
            'show_head',
            [
                'label' => esc_html__('Show Heading', 'conbix-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'conbix-toolkit'),
                'label_off' => esc_html__('No', 'conbix-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Services', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'show_head' => ['yes'],
                ],
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Popular Services', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'show_head' => ['yes'],
                ],
            ]
        );



        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button Text', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('all services', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'show_head'     => ['yes'],
                    'select_design' => ['design-1'],
                ],
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('Button URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_attr__('http://google.com', 'conbix-toolkit'),
                'condition' => [
                    'show_head' => ['yes'],
                    'select_design' => ['design-1'],
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Service Items', 'conbix-toolkit'),
            ]
        );

        $service_items = new Repeater();

        $service_items->add_control(
            'service_image',
            [
                'label' => esc_html__('BG Image', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $service_items->add_control(
            'service_title',
            [
                'label'   => esc_html__('Title', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $service_items->add_control(
            'service_description',
            [
                'label'   => esc_html__('Content', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $service_items->add_control(
            'service_btn',
            [
                'label' => esc_html__('Button Text', 'conbix-toolkit'),
                'type'  => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $service_items->add_control(
            'service_url',
            [
                'label' => esc_html__('Single URL', 'conbix-toolkit'),
                'type'  => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $service_items->add_control(
            'heading_one',
            [
                'label' => esc_html__('Service Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $service_items->start_controls_tabs(
            'style_tabs'
        );

        $service_items->start_controls_tab(
            'normal_icon',
            [
                'label' => esc_html__('Normal', 'conbix-toolkit'),
            ]
        );

        $service_items->add_control(
            'normal_img',
            [
                'label' => esc_html__('Normal Image', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $service_items->end_controls_tab();

        $service_items->start_controls_tab(
            'hover_icon',
            [
                'label' => esc_html__('Hover', 'conbix-toolkit'),
            ]
        );

        $service_items->add_control(
            'hover_img',
            [
                'label' => esc_html__('Hover Image', 'conbix-toolkit'),
                'type'  => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $service_items->end_controls_tab();

        $service_items->end_controls_tabs();




        $this->add_control(
            'service_items',
            [
                'label' => esc_html__('Service Items', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $service_items->get_controls(),
                'default' => [
                    [
                        'service_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'service_title'        => esc_html__('Business analytics', 'conbix-toolkit'),
                        'service_description'  => esc_html__('Proin pulvinar eu sem eu vehicula. Integer urna libero', 'conbix-toolkit'),
                        'service_btn'          => esc_html__('Read More', 'conbix-toolkit'),
                        'service_url'          => esc_attr__('http://google.com', 'conbix-toolkit'),
                    ],

                    [
                        'service_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'service_title'        => esc_html__('Business analytics', 'conbix-toolkit'),
                        'service_description'  => esc_html__('Proin pulvinar eu sem eu vehicula. Integer urna libero', 'conbix-toolkit'),
                        'service_btn'          => esc_html__('Read More', 'conbix-toolkit'),
                        'service_url'          => esc_attr__('http://google.com', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ service_title }}}',
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $blog_column = $settings['columns_desktop'] . ' ' . $settings['columns_tab'];


?>
        <?php if ('design-1' === $settings['select_design']) : ?>
            <div class="services__one">
                <div class="container">
                    <?php if ('yes' === $settings['show_head']) : ?>
                        <div class="row align-items-end mb-45">
                            <div class="col-xl-7 col-lg-8 lg-mb-30">
                                <div class="services__one-title lg-t-center">
                                    <span class="subtitle-one"><?php echo esc_html($settings['sub_title']); ?></span>
                                    <h2><?php echo esc_html($settings['title']); ?></h2>
                                </div>
                            </div>
                            <?php if (!empty($settings['btn_url'])) : ?>
                                <div class="col-xl-5 col-lg-4 t-right lg-t-center">
                                    <a class="btn-one" href="<?php echo esc_url($settings['btn_url']); ?>"><?php echo esc_html($settings['btn_text']); ?><i class="far fa-chevron-double-right"></i></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <?php foreach ($settings['service_items'] as $slide) : ?>
                            <div class="<?php echo esc_attr($blog_column); ?>">
                                <div class="services__one-item mt-25">
                                    <?php if (!empty($slide['normal_img']['url'])) : ?>
                                        <div class="services__one-item-icon">
                                            <img src="<?php echo esc_url($slide['normal_img']['url']) ?>" alt="Normal">
                                            <?php if (!empty($slide['hover_img']['url'])) : ?>
                                                <div class="services__one-item-icon-one">
                                                    <img src="<?php echo esc_url($slide['hover_img']['url']) ?>" alt="Hover">
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    <h4><a href="<?php echo esc_url($slide['service_url']); ?>"><?php echo esc_html($slide['service_title']); ?></a></h4>
                                    <p><?php echo esc_html($slide['service_description']); ?></p>
                                    <a class="simple-btn-2" href="<?php echo esc_url($slide['service_url']); ?>"><?php echo esc_html($slide['service_btn']); ?><i class="far fa-chevron-double-right"></i></a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <!-- Services Area Start -->
            <div class="services__two">
                <div class="container">
                    <?php if ('yes' === $settings['show_head']) : ?>
                        <div class="row mb-70 align-items-end">
                            <div class="col-xl-8 col-sm-8 lg-mb-30">
                                <div class="services__two-title sm-t-center">
                                    <span class="subtitle-two"><?php echo esc_html($settings['sub_title']); ?></span>
                                    <h2><?php echo esc_html($settings['title']); ?></h2>
                                </div>
                            </div>
                            <?php if ('yes' === $settings['show_arrow']) : ?>
                                <div class="col-xl-4 col-sm-4">
                                    <div class="services__two-arrow t-right sm-t-center">
                                        <div class="services__two-arrow-prev conbix-button-prev"><i class="fal fa-long-arrow-left"></i></div>
                                        <div class="services__two-arrow-next conbix-button-next"><i class="fal fa-long-arrow-right"></i></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="swiper services__two-slider">
                                <div class="swiper-wrapper">
                                    <?php foreach ($settings['service_items'] as $slide) : ?>
                                        <div class="services__two-item swiper-slide" style="background-image: url(<?php echo esc_url($slide['service_image']['url']) ?>)">
                                            <div class="services__two-item-content">
                                                <?php if (!empty($slide['normal_img']['url'])) : ?>
                                                    <div class="services__two-item-content-icon">
                                                        <img src="<?php echo esc_url($slide['normal_img']['url']) ?>" alt="Normal">
                                                    </div>
                                                <?php endif; ?>
                                                <h4><a href="<?php echo esc_url($slide['service_url']); ?>"><?php echo esc_html($slide['service_title']); ?></a></h4>
                                                <p><?php echo esc_html($slide['service_description']); ?></p>
                                                <a class="simple-btn-2" href="<?php echo esc_url($slide['service_url']); ?>"><?php echo esc_html($slide['service_btn']); ?><i class="far fa-chevron-double-right"></i></a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Services Area End -->
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']) : ?>

            <?php if ('yes' === $settings['active_slider']) { ?>

                <div class="services__three">
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-12 slider">
                                <?php if ('yes' === $settings['show_arrow']) : ?>
                                    <div class="services__three-arrow">
                                        <div class="services__three-arrow-prev conbix-button-prev"><i class="fal fa-long-arrow-left"></i></div>
                                        <div class="services__three-arrow-next conbix-button-next"><i class="fal fa-long-arrow-right"></i></div>
                                    </div>
                                <?php endif; ?>
                                <div class="swiper services__three-slider">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($settings['service_items'] as $slide) : ?>
                                            <div class="services__three-item swiper-slide">
                                                <img src="<?php echo esc_url($slide['service_image']['url']) ?>" alt="service item">
                                                <div class="services__three-item-content">
                                                    <?php if (!empty($slide['normal_img']['url'])) : ?>
                                                        <div class="services__three-item-content-icon">
                                                            <img src="<?php echo esc_url($slide['normal_img']['url']) ?>" alt="Normal">
                                                        </div>
                                                    <?php endif; ?>
                                                    <h4><a href="<?php echo esc_url($slide['service_url']); ?>"><?php echo esc_html($slide['service_title']); ?></a></h4>
                                                    <p><?php echo esc_html($slide['service_description']); ?></p>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <? } else { ?>
                <div class="container">
                    <div class="row">
                        <?php foreach ($settings['service_items'] as $slide) : ?>
                            <div class="<?php echo esc_attr($blog_column); ?>">
                                <div class="services__three-item mt-25 page">
                                    <img src="<?php echo esc_url($slide['service_image']['url']) ?>" alt="service item">
                                    <div class="services__three-item-content page">
                                        <?php if (!empty($slide['normal_img']['url'])) : ?>
                                            <div class="services__three-item-content-icon">
                                                <img src="<?php echo esc_url($slide['normal_img']['url']) ?>" alt="Normal">
                                            </div>
                                        <?php endif; ?>
                                        <h4><a href="<?php echo esc_url($slide['service_url']); ?>"><?php echo esc_html($slide['service_title']); ?></a></h4>
                                        <p><?php echo esc_html($slide['service_description']); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
        <?php }


        endif; ?>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Services);
