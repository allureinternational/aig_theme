<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if (!defined('ABSPATH')) exit;

class Widget_Form extends Widget_Base
{
    public function get_name()
    {
        return 'widget-form';
    }

    public function get_title()
    {
        return esc_html__('Widget Form', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'CTA', 'Form', 'Contact'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Image', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select a Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Design 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Design 02', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );

        $this->add_control(
            'bg_image',
            [
                'label' => esc_html__('Background Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'shape_one',
            [
                'label' => esc_html__('Shape One', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape_two',
            [
                'label' => esc_html__('Shape Two', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'left_content',
            [
                'label' => esc_html__('Contact Form', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'form_sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Get In Touch', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );


        $this->add_control(
            'form_title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Free Consultation', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'wpcf7_form_list',
            [
                'label'       => esc_html__('Select Contact Form', 'conbix-toolkit'),
                'label_block' => true,
                'type'        => Controls_Manager::SELECT,
                'options'     => $this->conbix_contact_form(),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'right_content',
            [
                'label' => esc_html__('All Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'content_sub',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Get In Touch', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );


        $this->add_control(
            'content_title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('We serving 30% Of Global 600 Companies', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'content_desc',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'content_other',
            [
                'label' => esc_html__('Other Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('client satisfaction in the globaly', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'video_url',
            [
                'label' => esc_html__('Video URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_attr__('https://www.youtube.com/watch?v=SZEflIVnhH8', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-2'],
                ],
            ]
        );


        $this->add_control(
            'user_profile',
            [
                'label' => esc_html__('User Images', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'img_user',
                        'label' => esc_html__('Image', 'conbix-toolkit'),
                        'type' => Controls_Manager::MEDIA,
                        'label_block' => true,
                    ],
                ],
                'condition' => [
                    'select_design' => ['design-1'],
                ],
                'default' => [
                    [
                        'img_user' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'img_user' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ],
                'title_field' => esc_html__('User Image', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'contact_items',
            [
                'label' => esc_html__('Email & Phone', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'phone_title',
            [
                'label' => esc_html__('Phone Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Emargency Help', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'user_phone',
            [
                'label' => esc_html__('Phone Number', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('+012 652 689 523', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'phone_url',
            [
                'label' => esc_html__('Phone URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('tel:+012652689523', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'mail_title',
            [
                'label' => esc_html__('Email Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Email drop Us', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'user_mail',
            [
                'label' => esc_html__('Your Email', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('conbix@gmail.com', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'mail_url',
            [
                'label' => esc_html__('Mail URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('mailto:conbix@gmail.com', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();
    }

    protected function conbix_contact_form()
    {

        if (!class_exists('WPCF7_ContactForm')) {
            return array();
        }

        $forms = \WPCF7_ContactForm::find(array(
            'orderby' => 'title',
            'order'   => 'ASC',
        ));

        if (empty($forms)) {
            return array();
        }

        $result = array();

        foreach ($forms as $item) {
            $key            = sprintf('%1$s::%2$s', $item->id(), $item->title());
            $result[$key] = $item->title();
        }

        return $result;
    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();

?>
        <?php if ('design-1' === $settings['select_design']) : ?>
            <div class="getIn__touch section-padding" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']) ?>)">
                <?php if (!empty($settings['shape_one']['url'])) : ?>
                    <img class="getIn__touch-shape left-right-animate2" src="<?php echo esc_url($settings['shape_one']['url']) ?>" alt="shape one">
                <?php endif; ?>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-5 lg-mb-30">
                            <div class="getIn__touch-left">
                                <div class="getIn__touch-left-title">
                                    <span class="subtitle-one"><?php echo esc_html($settings['form_sub_title']); ?></span>
                                    <h2><?php echo esc_html($settings['form_title']); ?></h2>
                                </div>
                               <?php if ( ! empty( $settings['wpcf7_form_list'] ) ) : ?>
                                <div class="getIn__touch-left-form">
                                <?php echo do_shortcode( '[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]' ); ?>
                                </div>
                              <?php endif;?>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-7">
                            <div class="getIn__touch-right">
                                <div class="getIn__touch-right-title">
                                    <h2><?php echo esc_html($settings['content_title']); ?></h2>
                                    <p><?php echo esc_html($settings['content_desc']); ?></p>
                                </div>
                                <div class="getIn__touch-right-bottom">
                                    <div class="getIn__touch-right-bottom-text">
                                        <h4><?php echo esc_html($settings['content_other']); ?></h4>
                                    </div>
                                    <?php if (!empty($settings['shape_two']['url'])) : ?>
                                        <div class="getIn__touch-right-bottom-shape">
                                            <img src="<?php echo esc_url($settings['shape_two']['url']) ?>" alt="shape two">
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($settings['user_profile'])) : ?>
                                        <div class="getIn__touch-right-bottom-image">
                                            <ul>
                                                <?php foreach ($settings['user_profile'] as $image) : ?>
                                                    <li>
                                                        <img src="<?php echo esc_url($image['img_user']['url']); ?>" alt="avatar">
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Emargency Help Area Start -->
            <div class="container">
                <div class="row">
                    <div class="col-xl-5"></div>
                    <div class="col-xl-7">
                        <div class="help__area">
                            <div class="help__area-item">
                                <div class="help__area-item-icon icon-animation">
                                    <i class="fal fa-phone-alt"></i>
                                </div>
                                <div class="help__area-item-info">
                                    <span class="text-three"><?php echo esc_html($settings['phone_title']); ?></span>
                                    <h5><a href="<?php echo esc_url($settings['phone_url']); ?>"><?php echo esc_html($settings['user_phone']); ?></a></h5>
                                </div>
                            </div>
                            <div class="help__area-item">
                                <div class="help__area-item-icon">
                                    <i class="fal fa-envelope-open-text"></i>
                                </div>
                                <div class="help__area-item-info">
                                    <span class="text-three"><?php echo esc_html($settings['mail_title']); ?></span>
                                    <h5><a href="<?php echo esc_url($settings['mail_url']); ?>"><?php echo esc_html($settings['user_mail']); ?></a></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Emargency Help Area End -->
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <div class="getIn__touch-three section-padding pb-0" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']) ?>)">
                <?php if (!empty($settings['shape_one']['url'])) : ?>
                    <img class="getIn__touch-three-shape left-right-animate2" src="<?php echo esc_url($settings['shape_one']['url']) ?>" alt="shape one">
                <?php endif; ?>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7 col-lg-7 lg-mb-50">
                            <div class="getIn__touch-three-left">
                                <div class="getIn__touch-three-left-title">
                                    <span class="subtitle-three"><?php echo esc_html($settings['content_sub']); ?></span>
                                    <h2><?php echo esc_html($settings['content_title']); ?></h2>
                                    <p><?php echo esc_html($settings['content_desc']); ?></p>
                                </div>
                                <div class="getIn__touch-three-left-video">
                                    <?php if (!empty($settings['video_url'])) : ?>
                                        <div class="getIn__touch-three-left-video-icon video video-pulse">
                                            <a class="video-popup" href="<?php echo esc_url($settings['video_url']); ?>"><i class="fal fa-play"></i></a>
                                        </div>
                                    <?php endif; ?>
                                    <div class="getIn__touch-three-left-video-text">
                                        <h4><?php echo esc_html($settings['content_other']); ?></h4>
                                    </div>
                                    <?php if (!empty($settings['shape_two']['url'])) : ?>
                                        <div class="getIn__touch-three-left-video-shape">
                                            <img src="<?php echo esc_url($settings['shape_two']['url']) ?>" alt="shape two">
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-5 col-lg-5">
                            <div class="getIn__touch-three-right">
                                <h3><?php echo esc_html($settings['form_title']); ?></h3>
                                <?php if ( ! empty( $settings['wpcf7_form_list'] ) ) : ?>
                                <div class="getIn__touch-three-right-form">
                                <?php echo do_shortcode( '[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]' ); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

<?php
    }
}

Plugin::instance()->widgets_manager->register(new Widget_Form);
