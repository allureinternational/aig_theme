<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Work_Process extends Widget_Base
{
    public function get_name()
    {
        return 'work-process';
    }

    public function get_title()
    {
        return esc_html__('Work Process', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Process', 'step', 'work'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'step_1',
            [
                'label' => esc_html__('Work Step 01', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'number_1',
            [
                'label' => esc_html__('Number', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('01', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_1',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_1',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'step_2',
            [
                'label' => esc_html__('Work Step 02', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'number_2',
            [
                'label' => esc_html__('Number', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('02', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_2',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_2',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'step_3',
            [
                'label' => esc_html__('Work Step 03', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'number_3',
            [
                'label' => esc_html__('Number', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('03', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_3',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_3',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'step_4',
            [
                'label' => esc_html__('Work Step 04', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'number_4',
            [
                'label' => esc_html__('Number', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('04', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_4',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_4',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
?>
        <div class="work__area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-sm-6 xl-mb-30">
                        <div class="work__area-item">
                            <span><?php echo esc_html($settings['number_1']); ?></span>
                            <h6><?php echo esc_html($settings['title_1']); ?></h6>
                            <p><?php echo esc_html($settings['desc_1']); ?></p>
                            <img class="work__area-item-arrow sm-display-n dark-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-1.png')); ?>" alt="icon">
                            <img class="work__area-item-arrow sm-display-n light-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-1-dark.png')); ?>" alt="icon">
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 sm-mb-30">
                        <div class="work__area-item">
                            <span><?php echo esc_html($settings['number_2']); ?></span>
                            <h6><?php echo esc_html($settings['title_2']); ?></h6>
                            <p><?php echo esc_html($settings['desc_2']); ?></p>
                            <img class="work__area-item-arrow xl-display-n dark-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-2.png')); ?>" alt="icon">
                            <img class="work__area-item-arrow xl-display-n light-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-2-dark.png')); ?>" alt="icon">
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 sm-mb-30">
                        <div class="work__area-item">
                            <span><?php echo esc_html($settings['number_3']); ?></span>
                            <h6><?php echo esc_html($settings['title_3']); ?></h6>
                            <p><?php echo esc_html($settings['desc_3']); ?></p>
                            <img class="work__area-item-arrow xl-display-n dark-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-1.png')); ?>" alt="icon">
                            <img class="work__area-item-arrow xl-display-n light-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-1-dark.png')); ?>" alt="icon">
                            <img class="work__area-item-arrow display-n xl-display-b sm-display-n dark-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-2.png')); ?>" alt="icon">
                            <img class="work__area-item-arrow display-n xl-display-b sm-display-n light-n" src=" <?php echo esc_url(get_theme_file_uri('assets/img/icon/arrow-2-dark.png')); ?>" alt="icon">
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6">
                        <div class="work__area-item">
                            <span><?php echo esc_html($settings['number_4']); ?></span>
                            <h6><?php echo esc_html($settings['title_4']); ?></h6>
                            <p><?php echo esc_html($settings['desc_4']); ?></p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Work_Process);
