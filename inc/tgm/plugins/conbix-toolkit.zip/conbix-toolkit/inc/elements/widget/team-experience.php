<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Team_expr extends Widget_Base
{
    public function get_name()
    {
        return 'Team-expr';
    }

    public function get_title()
    {
        return esc_html__('Team Experience', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Experience', 'Team', 'info'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'histroy_1',
            [
                'label' => esc_html__('Item 01', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'year_1',
            [
                'label' => esc_html__('Lavel', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('1', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_1',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_1',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'histroy_2',
            [
                'label' => esc_html__('Item 02', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'year_2',
            [
                'label' => esc_html__('Lavel', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('2', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_2',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_2',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'histroy_3',
            [
                'label' => esc_html__('Item 03', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'year_3',
            [
                'label' => esc_html__('Lavel', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('3', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_3',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_3',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'histroy_4',
            [
                'label' => esc_html__('Item 04', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'year_4',
            [
                'label' => esc_html__('Lavel', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('4', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_4',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_4',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $conbix_htmls = array(
            'span'   => array(),
        );
?>
        <div class="team__details team__details-experience-area">
            <div class="team__details-experience-area-item b-b">
                <h6><?php echo wp_kses($settings['year_1'], $conbix_htmls); ?></h6>
                <h4><?php echo esc_html($settings['title_1']); ?></h4>
                <p><?php echo wp_kses($settings['desc_1'], $conbix_htmls); ?></p>
            </div>
            <div class="team__details team__details-experience-area-item b-l">
                <h6><?php echo wp_kses($settings['year_2'], $conbix_htmls); ?></h6>
                <h4><?php echo esc_html($settings['title_2']); ?></h4>
                <p><?php echo wp_kses($settings['desc_2'], $conbix_htmls); ?></p>
            </div>
            <div class="team__details team__details-experience-area-item b-t">
                <h6><?php echo wp_kses($settings['year_3'], $conbix_htmls); ?></h6>
                <h4><?php echo esc_html($settings['title_3']); ?></h4>
                <p><?php echo wp_kses($settings['desc_3'], $conbix_htmls); ?></p>
            </div>
            <div class="team__details team__details-experience-area-item b-l b-t">
                <h6><?php echo wp_kses($settings['year_4'], $conbix_htmls); ?></h6>
                <h4><?php echo esc_html($settings['title_4']); ?></h4>
                <p><?php echo wp_kses($settings['desc_4'], $conbix_htmls); ?></p>
            </div>
        </div>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Team_expr);
