<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Questions extends Widget_Base
{
    public function get_name()
    {
        return 'questions';
    }

    public function get_title()
    {
        return esc_html__('Questions', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'two', 'image', 'Questions'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Have any questions?', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_1',
            [
                'label' => esc_html__('Image One', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_2',
            [
                'label' => esc_html__('Image Two', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $image1 = $settings['image_1'];
        $image2 = $settings['image_2'];
        $icon = $settings['icon'];


?>
        <div class="faq__two-left">
            <div class="faq__two-left-image">
                <?php
                if ($image1['url']) {
                    if (!empty($image1['alt'])) {
                        echo '<img src="' . esc_url($image1['url']) . '" alt="' . esc_attr($image1['alt']) . '" />';
                    } else {
                        echo '<img src="' . esc_url($image1['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                    }
                } ?>
                <?php
                if ($image2['url']) {
                    if (!empty($image2['alt'])) {
                        echo '<img class="faq__two-left-image-one" src="' . esc_url($image2['url']) . '" alt="' . esc_attr($image2['alt']) . '" />';
                    } else {
                        echo '<img class="faq__two-left-image-one" src="' . esc_url($image2['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                    }
                } ?>
                <div class="faq__two-left-image-question left-right-animate">
                    <?php
                    if ($icon['url']) {
                        if (!empty($icon['alt'])) {
                            echo '<img src="' . esc_url($icon['url']) . '" alt="' . esc_attr($icon['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($icon['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                        }
                    } ?>
                    <h6><?php echo esc_html($settings['title']); ?></h6>
                </div>
            </div>
        </div>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Questions);
