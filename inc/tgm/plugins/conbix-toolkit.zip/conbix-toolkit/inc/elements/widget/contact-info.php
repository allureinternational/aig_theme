<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Contact_Info extends Widget_Base
{
    public function get_name()
    {
        return 'contact-info';
    }

    public function get_title()
    {
        return esc_html__('Contact Info', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'contact', 'info', 'icon box'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Office Location', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('You are most welcome to visit office.', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('8502 Preston Rd. Inglewood', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $icon = $settings['icon'];
        $conbix_htmls = array(
            'a'      => array(
                'href'   => array(),
                'target' => array()
            ),
            'span'   => array(),
            'br'   => array(),
            'p'   => array(),
        );
?>

        <div class="contact__four-info">
            <div class="contact__four-info-icon">
                <?php
                if ($icon['url']) {
                    if (!empty($icon['alt'])) {
                        echo '<img src="' . esc_url($icon['url']) . '" alt="' . esc_attr($icon['alt']) . '" />';
                    } else {
                        echo '<img src="' . esc_url($icon['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                    }
                } ?>
            </div>
            <h4><?php echo esc_html($settings['title']); ?></h4>
            <span><?php echo esc_html($settings['sub_title']); ?></span>
            <?php echo wp_kses($settings['content'], $conbix_htmls); ?>
        </div>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Contact_Info);
