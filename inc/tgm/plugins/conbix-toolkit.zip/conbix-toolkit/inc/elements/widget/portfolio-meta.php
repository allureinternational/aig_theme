<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Portfolio_Meta extends Widget_Base
{
    public function get_name()
    {
        return 'portfolio-meta';
    }

    public function get_title()
    {
        return esc_html__('Portfolio Meta', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'meta', 'project', 'single', 'case study'];
    }

    protected function register_controls()

    {


        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'conbix-toolkit'),
            ]
        );

        $portfolio_meta = new Repeater();

        $portfolio_meta->add_control(
            'meta_name',
            [
                'label'   => esc_html__('Meta Name', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $portfolio_meta->add_control(
            'meta_content',
            [
                'label'   => esc_html__('Meta Content', 'conbix-toolkit'),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'portfolio_metas',
            [
                'label' => esc_html__('Portfolio Meta', 'conbix-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $portfolio_meta->get_controls(),
                'default' => [
                    [
                        'meta_name'     => esc_html__('Category:', 'conbix-toolkit'),
                        'meta_content'  => esc_html__('Consulting', 'conbix-toolkit'),
                    ],

                    [
                        'meta_name'     => esc_html__('Customer:', 'conbix-toolkit'),
                        'meta_content'  => esc_html__('ThemeOri', 'conbix-toolkit'),
                    ],
                ],

                'title_field' => '{{{ meta_name }}}',
            ]
        );



        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();


?>
        <div class="project__details-area-meta">
            <?php foreach ($settings['portfolio_metas'] as $meta) : ?>
                <div class="project__details-area-meta-item">
                    <h6><?php echo esc_html($meta['meta_name']); ?> <span><?php echo esc_html($meta['meta_content']); ?></span></h6>
                </div>
            <?php endforeach; ?>
        </div>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Portfolio_Meta);
