<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class History extends Widget_Base
{
    public function get_name()
    {
        return 'history';
    }

    public function get_title()
    {
        return esc_html__('Company History', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'History', 'Timeline', 'about'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'histroy_1',
            [
                'label' => esc_html__('History Item 01', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'image_1',
            [
                'label' => esc_html__('Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'year_1',
            [
                'label' => esc_html__('Year', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('2002', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_1',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_1',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'histroy_2',
            [
                'label' => esc_html__('History Item 02', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'image_2',
            [
                'label' => esc_html__('Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'year_2',
            [
                'label' => esc_html__('Year', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('2002', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_2',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_2',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'histroy_3',
            [
                'label' => esc_html__('History Item 03', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'image_3',
            [
                'label' => esc_html__('Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'year_3',
            [
                'label' => esc_html__('Year', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('2002', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_3',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_3',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'histroy_4',
            [
                'label' => esc_html__('History Item 04', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'image_4',
            [
                'label' => esc_html__('Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'year_4',
            [
                'label' => esc_html__('Year', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('2002', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_4',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_4',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'histroy_5',
            [
                'label' => esc_html__('History Item 05', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'image_5',
            [
                'label' => esc_html__('Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'year_5',
            [
                'label' => esc_html__('Year', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('2002', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_5',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_5',
            [
                'label' => esc_html__('Content', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'conbix-toolkit'),
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $image1 = $settings['image_1'];
        $image2 = $settings['image_2'];
        $image3 = $settings['image_3'];
        $image4 = $settings['image_4'];
        $image5 = $settings['image_5'];
?>
        <div class="company__history">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="company__history-area dark__image">
                            <div class="company__history-area-item">
                                <div class="company__history-area-item-left">
                                    <?php
                                    if ($image1['url']) {
                                        if (!empty($image1['alt'])) {
                                            echo '<img src="' . esc_url($image1['url']) . '" alt="' . esc_attr($image1['alt']) . '" />';
                                        } else {
                                            echo '<img src="' . esc_url($image1['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                        }
                                    } ?>
                                </div>
                                <div class="company__history-area-item-right">
                                    <div class="company__history-area-item-right-content mb-50 xl-mb-30">
                                        <div class="company__history-area-item-right-content-date">
                                            <span><?php echo esc_html($settings['year_1']); ?></span>
                                            <h5><?php echo esc_html($settings['title_1']); ?></h5>
                                        </div>
                                        <p><?php echo esc_html($settings['desc_1']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="company__history-area-items">
                                <div class="company__history-area-items-left order-last order-lg-first">
                                    <div class="company__history-area-items-left-content mb-50 xl-mb-30">
                                        <div class="company__history-area-items-left-content-date">
                                            <span><?php echo esc_html($settings['year_2']); ?></span>
                                            <h5><?php echo esc_html($settings['title_2']); ?></h5>
                                        </div>
                                        <p><?php echo esc_html($settings['desc_2']); ?></p>
                                    </div>
                                </div>
                                <div class="company__history-area-items-right">
                                    <div class="company__history-area-items-right-image">
                                        <?php
                                        if ($image2['url']) {
                                            if (!empty($image2['alt'])) {
                                                echo '<img src="' . esc_url($image2['url']) . '" alt="' . esc_attr($image2['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image2['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                            }
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <div class="company__history-area-item">
                                <div class="company__history-area-item-left">
                                    <div class="company__history-area-item-left-image">
                                        <?php
                                        if ($image3['url']) {
                                            if (!empty($image3['alt'])) {
                                                echo '<img src="' . esc_url($image3['url']) . '" alt="' . esc_attr($image3['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image3['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                            }
                                        } ?>
                                    </div>
                                </div>
                                <div class="company__history-area-item-right">
                                    <div class="company__history-area-item-right-content mb-50 xl-mb-30">
                                        <div class="company__history-area-item-right-content-date">
                                            <span><?php echo esc_html($settings['year_3']); ?></span>
                                            <h5><?php echo esc_html($settings['title_3']); ?></h5>
                                        </div>
                                        <p><?php echo esc_html($settings['desc_3']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="company__history-area-items">
                                <div class="company__history-area-items-left order-last order-lg-first">
                                    <div class="company__history-area-items-left-content mb-50 xl-mb-30">
                                        <div class="company__history-area-items-left-content-date">
                                            <span><?php echo esc_html($settings['year_4']); ?></span>
                                            <h5><?php echo esc_html($settings['title_4']); ?></h5>
                                        </div>
                                        <p><?php echo esc_html($settings['desc_4']); ?></p>
                                    </div>
                                </div>
                                <div class="company__history-area-items-right">
                                    <div class="company__history-area-items-right-image">
                                        <?php
                                        if ($image4['url']) {
                                            if (!empty($image4['alt'])) {
                                                echo '<img src="' . esc_url($image4['url']) . '" alt="' . esc_attr($image4['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image4['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                            }
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <div class="company__history-area-item">
                                <div class="company__history-area-item-left">
                                    <div class="company__history-area-item-left-image">
                                        <?php
                                        if ($image5['url']) {
                                            if (!empty($image5['alt'])) {
                                                echo '<img src="' . esc_url($image5['url']) . '" alt="' . esc_attr($image5['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image5['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                                            }
                                        } ?>
                                    </div>
                                </div>
                                <div class="company__history-area-item-right">
                                    <div class="company__history-area-item-right-content">
                                        <div class="company__history-area-item-right-content-date">
                                            <span><?php echo esc_html($settings['year_5']); ?></span>
                                            <h5><?php echo esc_html($settings['title_5']); ?></h5>
                                        </div>
                                        <p><?php echo esc_html($settings['desc_5']); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new History);
