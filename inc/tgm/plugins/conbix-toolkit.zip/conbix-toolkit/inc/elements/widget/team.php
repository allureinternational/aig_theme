<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if (!defined('ABSPATH')) exit;

class Teams extends Widget_Base
{
    public function get_name()
    {
        return 'team';
    }

    public function get_title()
    {
        return esc_html__('Team Member', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Teams', 'Member'];
    }

    protected function register_controls()

    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Team Style', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label'   => esc_html__('Select Team Style', 'conbix-toolkit'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Team Style 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Team Style 02', 'conbix-toolkit'),
                    'design-3' => esc_html__('Team Style 03', 'conbix-toolkit'),
                ],
                'default'      => 'design-1',
                'label_block'  => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_head',
            [
                'label' => esc_html__('Team Content', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'team_image',
            [
                'label' => esc_html__('Team Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'title_one',
            [
                'label' => esc_html__('Name', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Darrell Steward', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Position', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Sr Manager', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'team_url',
            [
                'label' => esc_html__('Single URL', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('http://google.com', 'conbix-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'show_social',
            [
                'label' => esc_html__('Show Social', 'conbix-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'conbix-toolkit'),
                'label_off' => esc_html__('No', 'conbix-toolkit'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'social_media',
            [
                'label'  => esc_html__('Social Media', 'conbix-toolkit'),
                'type'   => Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name'    => 'icon',
                        'label'   => esc_html__('Icon', 'conbix-toolkit'),
                        'type'    => Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'fab fa-facebook-f',
                            'library' => 'brands',
                        ],
                    ],
                    [
                        'name'    => 'link',
                        'label'   => esc_html__('Link', 'conbix-toolkit'),
                        'type'    => Controls_Manager::URL,
                        'default' => [
                            'url' => '#',
                        ],
                    ],
                ],
                'condition' => [
                    'show_social' => ['yes'],
                ],
                'title_field' => '{{{ icon }}}',
            ]
        );

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $team_image = $settings['team_image'];

?>
        <?php if ('design-1' === $settings['select_design']) : ?>
            <div class="team__area-item">
                <div class="team__area-item-image dark__image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                        }
                    } ?>
                    <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])) : ?>
                        <div class="team__area-item-image-icon">
                            <div class="team__area-item-image-social">
                                <ul>
                                    <?php foreach ($settings['social_media'] as $item) : ?>
                                        <li><a href="<?php echo esc_url($item['link']['url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <span><i class="fas fa-share-alt"></i></span>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="team__area-item-content">
                    <?php if (!empty($settings['team_url'])) { ?>
                        <h5><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h5>
                    <?php } else { ?>
                        <h5><?php echo esc_html($settings['title_one']); ?></h5>
                    <?php } ?>
                    <span class="text-eight"><?php echo esc_html($settings['sub_title']); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <div class="team__two-item">
                <div class="team__two-item-image dark__image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                        }
                    } ?>
                </div>
                <div class="team__two-item-content">
                    <?php if (!empty($settings['team_url'])) { ?>
                        <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                    <?php } else { ?>
                        <h4><?php echo esc_html($settings['title_one']); ?></h4>
                    <?php } ?>
                    <span class="text-eight"><?php echo esc_html($settings['sub_title']); ?></span>
                    <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])) : ?>
                        <div class="team__two-item-content-social">
                            <ul>
                                <?php foreach ($settings['social_media'] as $item) : ?>
                                    <li><a href="<?php echo esc_url($item['link']['url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                <?php endforeach; ?>
                            </ul>                        
                        </div>
                        <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']) : ?>
            <div class="team__three-item">
                <div class="team__three-item-image dark__image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'conbix-toolkit')) . '" />';
                        }
                    } ?>
                    <div class="team__three-item-image-info">
                        <div class="team__three-item-image-info-name">
                            <span class="text-eight"><?php echo esc_html($settings['sub_title']); ?></span>
                            <?php if (!empty($settings['team_url'])) { ?>
                                <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                            <?php } else { ?>
                                <h4><?php echo esc_html($settings['title_one']); ?></h4>
                            <?php } ?>
                        </div>
                        <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])) : ?>
                            <div class="team__three-item-image-info-icon">
                                <div class="team__three-item-image-info-social">
                                    <ul>
                                        <?php foreach ($settings['social_media'] as $item) : ?>
                                            <li><a href="<?php echo esc_url($item['link']['url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <span><i class="fas fa-share-alt"></i></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
<?php
    }
}

Plugin::instance()->widgets_manager->register(new Teams);
