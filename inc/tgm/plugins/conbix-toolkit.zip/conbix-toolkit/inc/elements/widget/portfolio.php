<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Portfolios extends Widget_Base
{
    public function get_name()
    {
        return 'portfolio';
    }

    public function get_title()
    {
        return esc_html__('Portfolio', 'conbix-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['conbix-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Work', 'Portfolio', 'Gallery'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Design', 'conbix-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'conbix-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Portfolio Style 01', 'conbix-toolkit'),
                    'design-2' => esc_html__('Portfolio Style 02', 'conbix-toolkit'),
                    'design-3' => esc_html__('Portfolio Style 03', 'conbix-toolkit'),
                    'design-4' => esc_html__('Portfolio Style 04', 'conbix-toolkit'),
                    'design-5' => esc_html__('Portfolio Style 05', 'conbix-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'theme_shape_img1',
            [
                'label' => esc_html__('Shape Image', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2'],
                ]
            ]
        );

        $this->add_control(
            'columns_desktop',
            [
                'label' => esc_html__('Columns On Desktop', 'conbix-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-xl-6' => esc_html__('Column 2', 'conbix-toolkit'),
                    'col-xl-4' => esc_html__('Column 3', 'conbix-toolkit'),
                    'col-xl-3' => esc_html__('Column 4', 'conbix-toolkit'),
                ],
                'default' => 'col-xl-4',
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-4', 'design-5'],
                ],
            ]
        );

        $this->add_control(
            'columns_tab',
            [
                'label' => esc_html__('Columns On Tablet', 'conbix-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-lg-12' => esc_html__('1 Column', 'conbix-toolkit'),
                    'col-lg-6' => esc_html__('2 Column', 'conbix-toolkit'),
                ],
                'default' => 'col-lg-6',
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-4', 'design-5'],
                ],
            ]
        );

        $this->add_control(
            'port_image',
            [
                'label' => esc_html__('Portfolio BG', 'conbix-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'filter_content',
            [
                'label' => esc_html__('Filter', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-5'],
                ],
            ]
        );

        $this->add_control(
            'show_filter',
            [
                'label' => esc_html__('Show Filter', 'conbix-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'conbix-toolkit'),
                'label_off' => esc_html__('No', 'conbix-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'all_text',
            [
                'label' => esc_html__('All Button Text', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('All', 'conbix-toolkit'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Head', 'conbix-toolkit'),
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'show_head',
            [
                'label' => esc_html__('Show Heading', 'conbix-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'conbix-toolkit'),
                'label_off' => esc_html__('No', 'conbix-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Portfolio', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'show_head' => ['yes'],
                ],
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'conbix-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Consulting Case Study', 'conbix-toolkit'),
                'label_block' => true,
                'condition' => [
                    'show_head' => ['yes'],
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'portfolio_query',
            [
                'label' => esc_html__('Portfolio Query', 'conbix-toolkit'),
            ]
        );


        $this->add_control(
            'portfolio_count',
            [
                'label' => esc_html__('Number of Portfolio', 'conbix-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['count'],
                'range' => [
                    'count' => [
                        'min' => 2,
                        'max' => 15,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'count',
                    'size' => 4,
                ],
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Categories', 'conbix-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => conbix_portfolio_categories(),
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $theme_shape_img1 = $settings['theme_shape_img1'];

        $grid_column = $settings['columns_desktop'] . ' ' . $settings['columns_tab'];
        $postCount = 0;
        $postsPerPage = $settings['portfolio_count']['size'];
        if (!empty($settings['category'])) {
            $portfolio_query = new \WP_Query(
                array(
                    'post_type' => 'portfolio',
                    'post_status' => 'publish',
                    'posts_per_page' => $postsPerPage,
                    'ignore_sticky_posts' => 1,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'portfolio_category',
                            'terms' => $settings['category'],
                            'field' => 'slug',
                        )
                    )
                )
            );
        } else {

            $portfolio_query = new \WP_Query(
                array(
                    'post_type' => 'portfolio',
                    'post_status' => 'publish',
                    'posts_per_page' => $postsPerPage,
                    'ignore_sticky_posts' => 1,
                )
            );
        }
        ?>
        <?php if ('design-1' === $settings['select_design']): ?>
            <!-- Portfolio Area Start -->
            <div class="portfolio__area dark__image">
                <div class="container-fluid p-0">
                    <?php if ('yes' === $settings['show_head']): ?>
                        <div class="row mb-60">
                            <div class="col-xl-12">
                                <div class="portfolio__area-title t-center">
                                    <span class="subtitle-one">
                                        <?php echo esc_html($settings['sub_title']); ?>
                                    </span>
                                    <h2>
                                        <?php echo esc_html($settings['title']); ?>
                                    </h2>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="swiper portfolio__area-slider">
                                <div class="swiper-wrapper">

                                    <?php while ($portfolio_query->have_posts()):
                                        $portfolio_query->the_post(); ?>
                                        <div class="portfolio__area-item swiper-slide">
                                            <img src="<?php the_post_thumbnail_url('large'); ?>"
                                                alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                            <div class="portfolio__area-item-content">
                                                <div class="portfolio__area-item-content-title">
                                                    <h4><a href="<?php echo esc_url(get_the_permalink()); ?>"><?php the_title(); ?></a>
                                                    </h4>

                                                    <span class="text-eight">
                                                        <?php
                                                        $terms = get_the_terms(get_the_ID(), 'portfolio_category');
                                                        if (!empty($terms)) {
                                                            echo $terms[0]->name;
                                                        }
                                                        ?>
                                                    </span>
                                                </div>
                                                <div class="portfolio__area-item-content-icon">
                                                    <a href="<?php echo esc_url(get_the_permalink()); ?>"><img
                                                            src="<?php echo esc_url(get_theme_file_uri('assets/img/icon/up-arrow.png')); ?>"
                                                            alt=""></a>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    endwhile;
                                    wp_reset_query();
                                    ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Portfolio Area End -->
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']): ?>
            <div class="portfolio dark__image">
                <?php
                if ($portfolio_query->have_posts()):
                    while ($portfolio_query->have_posts() && $postCount < $postsPerPage):
                        $portfolio_query->the_post();
                        $postCount++;
                        if ($postCount == 1) {
                            echo '<div class="portfolio-item active">';
                        } else {
                            echo '<div class="portfolio-item">';
                        }
                        ?>
                        <img src="<?php the_post_thumbnail_url('large'); ?>"
                            alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                        <div class="portfolio-item-inner">
                            <div class="portfolio-item-inner-title">
                                <h4>
                                    <?php the_title(); ?>
                                </h4>
                                <span>
                                    <?php
                                    $terms = get_the_terms(get_the_ID(), 'portfolio_category');
                                    if (!empty($terms)) {
                                        echo $terms[0]->name;
                                    }
                                    ?>
                                </span>
                            </div>
                            <div class="portfolio-item-inner-icon">
                                <a href="<?php the_permalink(); ?>"><i class="fal fa-long-arrow-up"></i></a>
                            </div>
                        </div>
                    </div>
                    <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>

            </div>
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']): ?>
            <!-- Portfolio Area Start -->
            <div class="portfolio__three" style="background-image: url(<?php echo esc_url($settings['port_image']['url']) ?>)">
                <div class="container-fluid">
                    <div class="row">
                        <?php while ($portfolio_query->have_posts()):
                            $portfolio_query->the_post(); ?>
                            <div class="col-xl-3 col-md-6 portfolio-border">
                                <div class="portfolio__three-item">
                                    <div class="portfolio__three-item-icon">
                                        <a href="<?php the_permalink(); ?>"><i class="fal fa-long-arrow-right"></i></a>
                                    </div>
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    <span>
                                        <?php
                                        $terms = get_the_terms(get_the_ID(), 'portfolio_category');
                                        if (!empty($terms)) {
                                            echo $terms[0]->name;
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                            <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </div>
            <!-- Portfolio Area End -->
        <?php endif; ?>

        <?php if ('design-4' === $settings['select_design']): ?>

            <!-- Project Area Start -->
            <div class="project__area">
                <div class="full-container">
                    <div class="row">
                        <?php while ($portfolio_query->have_posts()):
                            $portfolio_query->the_post(); ?>
                            <div class="<?php echo esc_attr($grid_column); ?>">
                                <div class="project__area-item mb-25">
                                    <img src="<?php the_post_thumbnail_url('large'); ?>"
                                        alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                    <div class="project__area-item-content">
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                        <span>
                                            <?php
                                            $terms = get_the_terms(get_the_ID(), 'portfolio_category');
                                            if (!empty($terms)) {
                                                echo $terms[0]->name;
                                            }
                                            ?>
                                        </span>
                                    </div>
                                    <div class="project__area-item-icon">
                                        <a href="<?php the_permalink(); ?>"><i class="far fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </div>
            <!-- Project Area End -->
        <?php endif; ?>
        <?php if ('design-5' === $settings['select_design']):


            $categories = $settings['category'];

            if (!empty($categories)) {
                $our_categories = array(
                    'taxonomy' => 'portfolio_category',
                    'hide_empty' => true,
                    'slug' => $categories
                );
            } else {
                $our_categories = array(
                    'taxonomy' => 'portfolio_category',
                    'hide_empty' => true,
                );
            }

            $categories_terms = get_terms($our_categories);
            ?>
            <!-- Portfolio Area Start -->
            <div class="project__one">
                <div class="container">
                    <?php if ('yes' === $settings['show_filter']): ?>
                        <div class="row">
                            <div class="col-xl-12 mb-30">
                                <div class="conbix__filter-button">
                                    <button class="active" data-filter="*">
                                        <?php echo esc_html($settings['all_text']); ?>
                                    </button>

                                    <?php if (!empty($categories_terms) && !is_wp_error($categories_terms)):
                                        foreach ($categories_terms as $term): ?>
                                            <button data-filter=".<?php echo esc_attr($term->name); ?>"><?php echo esc_html($term->name); ?></button>
                                    <?php endforeach;
                                    endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="row conbix__filter-active">
                        <?php while ($portfolio_query->have_posts()):
                            $portfolio_query->the_post(); ?>
                            <?php
                            $terms = get_the_terms(get_the_ID(), 'portfolio_category');
                            if (!empty($terms)) {
                                $show_cat = $terms[0]->name;
                            }
                            ?>
                            <div class="<?php echo esc_attr($grid_column); ?> mt-30 <?php echo esc_attr($show_cat); ?>">
                                <div class="project__one-item">
                                    <img class="img__full" src="<?php the_post_thumbnail_url('large'); ?>"
                                        alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                    <div class="project__one-item-content">
                                        <span>
                                            <?php echo esc_html($show_cat); ?>
                                        </span>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    </div>
                                    <div class="project__one-item-icon">
                                        <a href="<?php the_permalink(); ?>"><i class="fal fa-long-arrow-up"></i></a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </div>
            <!-- Portfolio Area End -->
        <?php endif; ?>
        <?php if ('design-2' === $settings['select_design']): ?>
        <style>
        <?php if (!empty($theme_shape_img1['url'])): ?>
        .portfolio-item.active::after {
            background-image: url('<?php echo esc_url($theme_shape_img1['url']);?>');
        }
        <?php endif; ?>
        </style>
    <?php endif; ?>
    <?php
    }
}

Plugin::instance()->widgets_manager->register(new Portfolios);